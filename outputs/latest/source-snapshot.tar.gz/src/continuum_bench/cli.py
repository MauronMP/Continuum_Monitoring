from __future__ import annotations

import argparse
import json
from dataclasses import replace
from pathlib import Path
import webbrowser

from .config import load_config
from .validation import validate_project

REASONER_CHOICES = ("rdfs", "hermit", "openllet", "jfact", "konclude")


def _family_timeout_updates(args: argparse.Namespace, *, recovery: bool = False) -> dict[str, float]:
    """Map global deadline options to family-specific workload contracts."""
    if args.timeout_seconds is not None:
        updates = {
            "request_timeout_seconds": args.timeout_seconds,
            "point_timeout_seconds": args.timeout_seconds,
        }
        if recovery:
            updates["recovery_timeout_seconds"] = args.timeout_seconds
        return updates
    updates = {}
    if args.request_timeout_seconds is not None:
        updates["request_timeout_seconds"] = args.request_timeout_seconds
    if args.point_timeout_seconds is not None:
        updates["point_timeout_seconds"] = args.point_timeout_seconds
    return updates


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="continuum-bench",
        description=(
            "Evaluate policy-driven monitoring on physical continuum "
            "infrastructure, using the ontology as an internal mechanism."
        ),
    )
    parser.add_argument(
        "--config",
        default="configs/benchmark.toml",
        help="Benchmark TOML file (default: configs/benchmark.toml)",
    )
    parser.add_argument(
        "--topology-file",
        help="Physical topology manifest override",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    parser.add_argument("--timeout-seconds", type=float, help="Override request, phase and point budgets for physical benchmarks")
    parser.add_argument(
        "--unlimited",
        action="store_true",
        help=(
            "Optionally disable all benchmark deadlines and timeout pruning; "
            "a non-terminating reasoner may block the run indefinitely"
        ),
    )
    parser.add_argument("--keep-going", action="store_true", help="Attempt later points even after a timeout")
    parser.add_argument("--repetitions", type=int, help="Override experiment repetitions")
    parser.add_argument("--timeout-mode", choices=("bounded", "unlimited"), help="Override limits.timeout_mode")
    for scope in ("request", "phase", "point"):
        parser.add_argument(f"--{scope}-timeout-seconds", type=float, help=f"Override the {scope} budget independently")
    parser.add_argument("--skip-after-timeouts", type=int, help="Consecutive timeouts required before configured skip triggers latch")
    for scope in ("repetitions", "larger-points", "cumulative-stages"):
        parser.add_argument(f"--skip-{scope}", action=argparse.BooleanOptionalAction, default=None)

    from .monitoring.container_scale.cli import register as register_container_scale
    register_container_scale(subparsers)
    from .monitoring.adaptive_monitoring.cli import register as register_adaptive
    register_adaptive(subparsers)

    report = subparsers.add_parser("report", help="Audit physical evidence and generate scientific PNG figures")
    report.add_argument("--input-dir", default="outputs")
    report.add_argument("--validation-dir", help="Optional separate physical-load result directory")
    report.add_argument("--output-dir", default="outputs/report")
    suite = subparsers.add_parser("suite", help="Run all physical test families sequentially with recorded logs")
    suite.add_argument("--patient", action="store_true", help="Use one-hour budgets and attempt every configured point")
    suite.add_argument("--output-dir", default="outputs/suites")
    suite.add_argument("--dry-run", action="store_true")
    suite.add_argument("--load-config", default="configs/load-benchmark.toml")
    suite.add_argument("--experiment-config", default="configs/experiments.toml")
    suite.add_argument("--distributed-reasoning-config", default="configs/distributed-reasoning.toml")
    suite.add_argument("--campaign-config", default="configs/campaign.toml")
    suite.add_argument("--policy-evaluation-config", default="configs/policy-evaluation.toml")
    suite.add_argument("--families", nargs="+", choices=("software","validation","monitoring","load","experiments","campaign","policy-evaluation","report"))
    campaign = subparsers.add_parser("campaign", help="Run configurable physical scalability and policy-cost axes")
    campaign.add_argument("--campaign-config", default="configs/campaign.toml")
    campaign.add_argument("--output-dir", default="outputs/campaign")
    campaign.add_argument("--axis", action="append")
    campaign.add_argument("--topology-name", default="physical")
    campaign.add_argument("--validate-only", action="store_true")

    doctor = subparsers.add_parser(
        "doctor",
        help="Read-only installation and SSH diagnostics",
    )
    doctor.add_argument("--physical", action="store_true")
    doctor.add_argument("--owl", action="store_true")
    doctor.add_argument("--json", action="store_true")

    subparsers.add_parser(
        "validate",
        help="Run syntax, ontology, policy and query checks",
    )

    preflight = subparsers.add_parser(
        "preflight",
        help="Validate load/experiment sizes before contacting workers",
    )
    preflight.add_argument(
        "--load-config", default="configs/load-benchmark.toml"
    )
    preflight.add_argument(
        "--experiment-config", default="configs/experiments.toml"
    )

    owl_validate = subparsers.add_parser(
        "owl-validate",
        help="Validate OWL consistency with external DL reasoners",
    )
    owl_validate.add_argument(
        "--reasoner-config", default="configs/owl-reasoners.toml"
    )

    owl_validate.add_argument(
        "--output", default="outputs/validation/owl-reasoners.json"
    )
    owl_validate.add_argument(
        "--require-all",
        action="store_true",
        help="Fail when any configured reasoner is unavailable or inconsistent",
    )

    topology = subparsers.add_parser(
        "topology",
        help="Validate or inspect a topology manifest",
    )
    topology.add_argument("action", choices=("validate", "show"))
    topology.add_argument("--name", default="physical")



    fragments = subparsers.add_parser(
        "fragments",
        help="Export authority-aware RDF fragments for physical nodes",
    )
    fragments.add_argument("--users", type=int, default=0)
    fragments.add_argument("--topology-name", default="physical")
    fragments.add_argument("--output-dir", default="outputs/fragments/physical")
    fragments.add_argument("--ssh-user")

    physical = subparsers.add_parser(
        "physical",
        help="Deploy, manage or benchmark a physical continuum",
    )
    physical.add_argument(
        "action",
        choices=(
            "authorize",
            "prepare",
            "deploy",
            "start",
            "status",
            "stop",
            "cumulative",
            "scalability",
            "all",
        ),
    )
    physical.add_argument("--reasoner", action="append", choices=REASONER_CHOICES, help="Select one or more configured benchmark backends")
    physical.add_argument("--topology-name", default="physical")
    physical.add_argument("--ssh-user")
    physical.add_argument("--with-dl-reasoners", action="store_true", help="Install and verify native reasoner runtimes during online deployment")
    physical.add_argument("--output-dir", default="outputs/monitoring")
    physical.add_argument(
        "--layout",
        choices=("replicated", "distributed"),
        default="distributed",
        help="Physical ontology placement (default: distributed)",
    )
    physical.add_argument(
        "--skip-result-validation",
        action="store_true",
        help="Skip bounded reference validation for distributed query results",
    )

    load = subparsers.add_parser(
        "load",
        help="Run or plot the distributed load benchmark",
    )
    load.add_argument(
        "target", choices=("physical", "plot")
    )
    load.add_argument(
        "--load-config",
        default="configs/load-benchmark.toml",
        help="Load profile TOML (default: configs/load-benchmark.toml)",
    )
    load.add_argument("--topology-name")
    load.add_argument(
        "--dimension",
        action="append",
        choices=(
            "events_per_second",
            "users",
            "target_triples",
            "rule_count",
            "node_count",
        ),
    )
    load.add_argument("--profile", action="append")
    load.add_argument("--output-dir", default="outputs/load")
    load.add_argument("--show", action="store_true")

    experiment = subparsers.add_parser(
        "experiment",
        help=(
            "Run physical scale-out, hardware reasoning or "
            "distributed-ontology experiments"
        ),
    )
    experiment_commands = experiment.add_subparsers(
        dest="experiment_name",
        required=True,
    )

    def add_experiment_arguments(command_parser: argparse.ArgumentParser) -> None:
        command_parser.add_argument(
            "target",
            choices=("physical",),
            nargs="?",
            default="physical",
        )
        command_parser.add_argument(
            "--experiment-config",
            default="configs/experiments.toml",
        )
        command_parser.add_argument("--topology-name")
        command_parser.add_argument("--output-dir", default="outputs/experiments")
        command_parser.add_argument(
            "--reasoner",
            action="append",
            choices=REASONER_CHOICES,
        )
        command_parser.add_argument("--profile", action="append")

    for name in (
        "scale-out",
        "reasoning-hardware",
        "distributed-ontology",
        "distributed-reasoning-scalability",
        "all",
    ):
        add_experiment_arguments(experiment_commands.add_parser(name))
    selected_parser = experiment_commands.choices["distributed-reasoning-scalability"]
    selected_parser.add_argument(
        "--distributed-reasoning-config",
        default="configs/distributed-reasoning.toml",
    )
    experiment_commands.choices["all"].add_argument(
        "--distributed-reasoning-config",
        default=None,
        help="Include the distributed reasoning scalability family using this TOML",
    )

    experiment_plot = experiment_commands.add_parser("plot")
    experiment_plot.add_argument(
        "suite",
        choices=(
            "scale-out",
            "reasoning-hardware",
            "distributed-ontology",
            "distributed-reasoning-scalability",
            "all",
        ),
    )
    experiment_plot.add_argument("--output-dir", default="outputs/experiments")
    experiment_plot.add_argument("--show", action="store_true")

    experiment_analyze = experiment_commands.add_parser("analyze")
    experiment_analyze.add_argument("--output-dir", default="outputs/experiments")
    experiment_analyze.add_argument("--show", action="store_true")

    study = subparsers.add_parser(
        "study",
        help="Generate reproducible traces and policy-category cost summaries",
    )
    study.add_argument("action", choices=("trace", "category-cost"))
    study.add_argument(
        "--study-config",
        default="configs/policy-cost-study.toml",
        help="Policy-cost study TOML file",
    )
    study.add_argument(
        "--topology-name",
        help="Topology name (defaults to the selected target)",
    )
    study.add_argument(
        "--target",
        choices=("physical",),
        default="physical",
        help="Execution topology used to generate the trace",
    )
    study.add_argument("--output-dir", default="outputs/study")
    study.add_argument(
        "--events",
        default="outputs/load/event-runs.csv",
        help="Request/event CSV used by category-cost analysis",
    )

    policy_evaluation = subparsers.add_parser(
        "policy-evaluation",
        help="Evaluate functional policy decisions, adaptation, scalability and cost",
    )
    policy_evaluation.add_argument(
        "action",
        choices=(
            "effectiveness",
            "dynamic-adaptation",
            "scalability",
            "computational-cost",
            "all",
            "plot",
        ),
    )
    policy_evaluation.add_argument(
        "--evaluation-config",
        default="configs/policy-evaluation.toml",
    )
    policy_evaluation.add_argument(
        "--output-dir",
        default="outputs/policy-evaluation",
    )
    policy_evaluation.add_argument("--show", action="store_true")
    return parser


def _manifest_path(config, override: str | None) -> Path:
    path = Path(override) if override else config.topology_file
    return path if path.is_absolute() else config.root / path


def _target_manifest_path(config, override: str | None, target: str) -> Path:
    if override:
        return _manifest_path(config, override)
    if target in {"physical"}:
        return config.root / f"configs/topologies/{target}/topology.toml"
    return _manifest_path(config, None)


def _target_topology(config, args, target: str):
    from .topology import load_topology

    name = getattr(args, "topology_name", None) or target
    return load_topology(
        _target_manifest_path(config, args.topology_file, target), name
    )


def _physical_inventory(config, args):
    from .physical_cluster import load_physical_inventory

    return load_physical_inventory(
        _manifest_path(config, args.topology_file),
        ssh_user=getattr(args, "ssh_user", None),
        topology_name=getattr(args, "topology_name", "physical"),
    )


def _open_paths(paths: list[Path]) -> None:
    for path in paths:
        if path.suffix == ".png":
            webbrowser.open(path.resolve().as_uri())


def _dispatch(args) -> int:
    if args.command == "doctor":
        from .environment import main as doctor_main

        config_path = Path(args.config).resolve()
        options = ["--root", str(config_path.parents[1])]
        if args.physical:
            options.append("--physical")
        if args.owl:
            options.append("--owl")
        if args.json:
            options.append("--json")
        return doctor_main(options)

    config = load_config(args.config)
    if args.command == "adaptive-monitoring":
        from .monitoring.adaptive_monitoring.cli import dispatch
        return dispatch(args, config)
    if args.command == "container-scale":
        from .monitoring.container_scale.cli import dispatch
        return dispatch(args, config)
    if args.command == "physical" and args.reasoner:
        config = replace(config, reasoners=tuple(dict.fromkeys(args.reasoner)))

    if args.timeout_seconds is not None:
        import math
        if not math.isfinite(args.timeout_seconds) or args.timeout_seconds <= 5:
            raise ValueError("--timeout-seconds must be finite and greater than 5")
        config = replace(config, distributed=replace(config.distributed, request_timeout_seconds=args.timeout_seconds),
                         limits=replace(config.limits, phase_timeout_seconds=args.timeout_seconds, point_timeout_seconds=args.timeout_seconds))
    import math
    transport_updates = {}
    limit_updates = {}
    for scope in ("request", "phase", "point"):
        value = getattr(args, f"{scope}_timeout_seconds")
        if value is not None:
            if not math.isfinite(value) or value <= config.distributed.worker_timeout_margin_seconds:
                raise ValueError(f"--{scope}-timeout-seconds must be finite and exceed the worker response margin")
            (transport_updates if scope == "request" else limit_updates)[f"{scope}_timeout_seconds"] = value
    for argument, field in (("skip_repetitions", "skip_repetitions_after_timeout"),
                            ("skip_larger_points", "skip_larger_sizes_after_timeout"),
                            ("skip_cumulative_stages", "skip_cumulative_stages_after_timeout")):
        value = getattr(args, argument)
        if value is not None:
            limit_updates[field] = value
    if args.skip_after_timeouts is not None:
        limit_updates["consecutive_timeout_threshold"] = args.skip_after_timeouts
    if args.timeout_mode:
        limit_updates["timeout_mode"] = args.timeout_mode
    if args.keep_going or args.unlimited:
        limit_updates.update(stop_scaling_after_timeout=False, skip_repetitions_after_timeout=False,
                             skip_larger_sizes_after_timeout=False, skip_cumulative_stages_after_timeout=False)
    if args.unlimited:
        limit_updates["timeout_mode"] = "unlimited"
    config = replace(config, distributed=replace(config.distributed, **transport_updates),
                     limits=replace(config.limits, **limit_updates))
    if args.repetitions is not None:
        if args.repetitions < 1: raise ValueError("--repetitions must be positive")
        config = replace(config, repetitions=args.repetitions)
    if args.command == "report":
        from .monitoring.publication import generate_report
        report = generate_report(config.root, config.resolve(Path(args.input_dir)), config.resolve(Path(args.output_dir)), config.resolve(Path(args.validation_dir)) if args.validation_dir else None)
        print(json.dumps(report, indent=2))
        return 0
    if args.command == "suite":
        from .monitoring.suite import run_suite
        result = run_suite(config.root, Path(args.config).resolve(), config.resolve(Path(args.output_dir)),
                           patient=args.patient, unlimited=args.unlimited, timeout_seconds=args.timeout_seconds, repetitions=args.repetitions,
                           families=args.families, dry_run=args.dry_run,
                           timeout_mode=args.timeout_mode, request_timeout_seconds=args.request_timeout_seconds,
                           phase_timeout_seconds=args.phase_timeout_seconds, point_timeout_seconds=args.point_timeout_seconds,
                           skip_after_timeouts=args.skip_after_timeouts, skip_repetitions=args.skip_repetitions,
                           skip_larger_points=args.skip_larger_points, skip_cumulative_stages=args.skip_cumulative_stages,
                           keep_going=args.keep_going, topology_file=args.topology_file,
                           load_config=args.load_config, experiment_config=args.experiment_config,
                           distributed_reasoning_config=args.distributed_reasoning_config,
                           campaign_config=args.campaign_config,
                           policy_evaluation_config=args.policy_evaluation_config)
        print(json.dumps(result, indent=2))
        return int(any(step.get("returncode", 0) != 0 or step.get("status") in {"failed", "missing_evidence"} for step in result["steps"]))

    if args.command == "campaign":
        from .monitoring.campaign_config import load_campaign
        from .monitoring.campaign import run_campaign
        from .monitoring.campaign_infrastructure import PhysicalInfrastructure
        campaign = load_campaign(config.resolve(Path(args.campaign_config)))
        campaign = replace(campaign, **_family_timeout_updates(args))
        if args.repetitions:
            campaign = replace(campaign, repetitions=args.repetitions)
        if args.axis:
            missing = set(args.axis) - {axis.name for axis in campaign.axes}
            if missing:
                raise ValueError(f"Unknown campaign axes: {sorted(missing)}")
            campaign = replace(campaign, axes=tuple(a for a in campaign.axes if a.name in args.axis))
        topology = _target_topology(config, args, "physical")
        if max(w.physical_nodes for _, _, w in campaign.points()) > len(topology.active_nodes):
            raise ValueError("Campaign requests more physical nodes than configured")
        if args.validate_only:
            print(json.dumps(campaign.public(), indent=2))
            return 0
        directory, failures = run_campaign(campaign, PhysicalInfrastructure(topology, config), config.resolve(Path(args.output_dir)))
        print(json.dumps({"output": str(directory), "failed_points": failures}, indent=2))
        return 1 if failures else 0

    if args.command == "validate":
        report = validate_project(config)
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return 0 if report["ok"] else 1

    if args.command == "preflight":
        from .preflight import validate_default_workloads

        load_path = config.root / args.load_config
        experiment_path = config.root / args.experiment_config
        report = validate_default_workloads(config, load_path, experiment_path)
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return 0

    if args.command == "owl-validate":
        from .owl_validation import validate_external_reasoners

        reasoner_config = Path(args.reasoner_config)
        if not reasoner_config.is_absolute():
            reasoner_config = config.root / reasoner_config
        output = Path(args.output)
        if not output.is_absolute():
            output = config.root / output
        report = validate_external_reasoners(
            config.root, reasoner_config, output
        )
        print(json.dumps(report, indent=2, ensure_ascii=False))
        completed = [
            item for item in report["reasoners"]
            if item["status"] == "completed"
        ]
        success = bool(completed) and all(
            item.get("consistent") is True for item in completed
        )
        if args.require_all:
            success = success and report["all_available"] and report["all_consistent"]
        return 0 if success else 1

    if args.command == "topology":
        from .topology import load_topology, load_topology_manifest

        manifest_path = _target_manifest_path(
            config, args.topology_file, args.name
        )
        if args.action == "validate":
            manifest = load_topology_manifest(manifest_path)
            print(json.dumps(manifest.public(), indent=2, ensure_ascii=False))
            return 0
        selected = load_topology(manifest_path, args.name)
        print(json.dumps(selected.public(), indent=2, ensure_ascii=False))
        return 0


    if args.command == "fragments":
        from .monitoring import export_physical_fragments

        if args.users < 0:
            raise ValueError("--users must be zero or greater")
        inventory = _physical_inventory(config, args)
        paths = export_physical_fragments(
            config,
            inventory,
            args.users,
            config.root / args.output_dir,
        )
        print(json.dumps({"fragments": [str(path) for path in paths]}, indent=2))
        return 0

    if args.command == "physical":
        from .monitoring import run_physical_monitoring_suite
        from .physical_cluster import (
            authorize_cluster,
            deploy_cluster,
            write_offline_manifest,
            start_cluster,
            status_cluster,
            stop_cluster,
        )

        inventory = _physical_inventory(config, args)
        if args.action == "prepare":
            readiness_root = (
                config.root / "outputs/validation/readiness"
                if args.output_dir == "outputs/monitoring"
                else config.resolve(Path(args.output_dir))
            )
            report = write_offline_manifest(config.root, inventory, readiness_root / "offline-readiness.json")
            print(json.dumps(report, indent=2))
            return 0 if report["local_files_ready"] else 1
        if args.action == "authorize":
            authorize_cluster(inventory)
            return 0
        if args.action == "deploy":
            if args.with_dl_reasoners:
                deploy_cluster(config.root, inventory, with_dl_reasoners=True)
            else:
                deploy_cluster(config.root, inventory)
            return 0
        if args.action == "start":
            start_cluster(config.root, inventory)
            return 0
        if args.action == "status":
            statuses = status_cluster(inventory)
            return 0 if all(item["healthy"] for item in statuses) else 1
        if args.action == "stop":
            stop_cluster(config.root, inventory)
            return 0

        outputs = run_physical_monitoring_suite(
            config,
            inventory,
            config.root / args.output_dir,
            suite=args.action,
            layout=args.layout,
            validate_results=not args.skip_result_validation,
        )
        print(json.dumps(outputs, indent=2, ensure_ascii=False))
        return 0

    if args.command == "load":
        from .monitoring.load_benchmark import run_load_benchmark
        from .monitoring.load_config import load_load_config, select_load_profiles

        output_root = config.root / args.output_dir
        if args.target == "plot":
            from .monitoring.load_reporting import plot_load_comparison

            paths = plot_load_comparison(output_root)
            if args.show:
                _open_paths(paths)
            print(json.dumps({"load_plots": [str(path) for path in paths]}, indent=2))
            return 0
        workload = select_load_profiles(
            load_load_config(config.root / args.load_config),
            dimensions=args.dimension,
            names=args.profile,
        )
        from .preflight import validate_load_workload

        workload = replace(workload, **_family_timeout_updates(args, recovery=True))
        if args.repetitions:
            workload = replace(workload, repetitions=args.repetitions)
        if args.keep_going or args.unlimited:
            workload = replace(workload, stop_after_timeout=False)
        validate_load_workload(config, workload)
        endpoints = None
        topology = _target_topology(config, args, args.target)
        endpoints = topology.endpoints()
        output = run_load_benchmark(
            config,
            workload,
            args.target,
            output_root,
            endpoints,
            topology,
        )
        print(json.dumps({args.target: str(output)}, indent=2, ensure_ascii=False))
        return 0

    if args.command == "experiment":
        from .monitoring.experiment_config import (
            load_experiment_config,
            select_reasoning_profiles,
        )
        from .monitoring.experiments import EXPERIMENTS, run_experiment

        output_root = config.root / args.output_dir
        if args.experiment_name == "plot":
            from .monitoring.experiment_reporting import plot_experiments

            selected = EXPERIMENTS if args.suite == "all" else (args.suite,)
            paths = plot_experiments(output_root, selected)
            if args.show:
                _open_paths(paths)
            print(
                json.dumps(
                    {"experiment_plots": [str(path) for path in paths]},
                    indent=2,
                    ensure_ascii=False,
                )
            )
            return 0
        if args.experiment_name == "analyze":
            from .monitoring.experiment_analysis import analyze_experiments
            from .monitoring.experiment_reporting import plot_claim_analysis

            paths = analyze_experiments(output_root)
            paths.extend(plot_claim_analysis(output_root))
            if args.show:
                _open_paths(paths)
            print(
                json.dumps(
                    {"experiment_analysis": [str(path) for path in paths]},
                    indent=2,
                    ensure_ascii=False,
                )
            )
            return 0

        distributed_outputs = {}
        run_distributed_reasoning = (
            args.experiment_name == "distributed-reasoning-scalability"
            or (
                args.experiment_name == "all"
                and args.distributed_reasoning_config is not None
            )
        )
        if run_distributed_reasoning:
            from .monitoring.distributed_reasoning_config import (
                load_distributed_reasoning_config,
                override_distributed_reasoning_config,
            )
            from .monitoring.distributed_reasoning_scalability import run_distributed_reasoning_scalability
            distributed_path = Path(args.distributed_reasoning_config)
            if not distributed_path.is_absolute():
                distributed_path = config.root / distributed_path
            distributed_workload = override_distributed_reasoning_config(
                load_distributed_reasoning_config(distributed_path),
                repetitions=args.repetitions,
                timeout_seconds=args.timeout_seconds,
                request_timeout_seconds=args.request_timeout_seconds,
                point_timeout_seconds=args.point_timeout_seconds,
                reasoners=args.reasoner,
            )
            topology = _target_topology(config, args, args.target)
            distributed_outputs["distributed-reasoning-scalability"] = str(
                run_distributed_reasoning_scalability(
                    config, distributed_workload, args.target, output_root,
                    endpoint_urls=topology.endpoints(),
                    topology=topology,
                )
            )
            if args.experiment_name == "distributed-reasoning-scalability":
                print(json.dumps(distributed_outputs, indent=2, ensure_ascii=False))
                return 0

        experiment_path = Path(args.experiment_config)
        if not experiment_path.is_absolute():
            experiment_path = config.root / experiment_path
        workload = select_reasoning_profiles(
            load_experiment_config(experiment_path),
            args.profile,
        )
        from .preflight import validate_experiment_workload

        workload = replace(workload, **_family_timeout_updates(args))
        if args.repetitions:
            workload = replace(workload, repetitions=args.repetitions)
        if args.keep_going or args.unlimited:
            workload = replace(workload, stop_after_timeout=False)
        validate_experiment_workload(config, workload, experiment_path)
        if args.reasoner:
            config = replace(config, reasoners=tuple(args.reasoner))
        endpoints = None
        topology = _target_topology(config, args, args.target)
        endpoints = topology.endpoints()
        core_experiments = tuple(name for name in EXPERIMENTS if name != "distributed-reasoning-scalability")
        selected = core_experiments if args.experiment_name == "all" else (args.experiment_name,)
        outputs = distributed_outputs | {
            name: str(
                run_experiment(
                    name,
                    config,
                    workload,
                    args.target,
                    output_root,
                    endpoint_urls=endpoints,
                    topology=topology,
                )
            )
            for name in selected
        }
        print(json.dumps(outputs, indent=2, ensure_ascii=False))
        return 0

    if args.command == "study":
        from .monitoring.study import analyze_category_costs, generate_study_trace
        from .monitoring.study.config import load_study_config

        output_root = config.root / args.output_dir
        if args.action == "trace":
            study_config_path = Path(args.study_config)
            if not study_config_path.is_absolute():
                study_config_path = config.root / study_config_path
            paths = generate_study_trace(
                config,
                load_study_config(study_config_path),
                output_root,
                topology_name=args.topology_name,
                target=args.target,
            )
            print(
                json.dumps(
                    {"study_trace": [str(path) for path in paths]},
                    indent=2,
                    ensure_ascii=False,
                )
            )
            return 0
        events_path = Path(args.events)
        if not events_path.is_absolute():
            events_path = config.root / events_path
        paths = analyze_category_costs(
            config,
            events_path,
            output_root / "category-cost",
        )
        print(
            json.dumps(
                {"category_cost": [str(path) for path in paths]},
                indent=2,
                ensure_ascii=False,
            )
        )
        return 0

    if args.command == "policy-evaluation":
        from .monitoring.policy_evaluation.config import load_policy_evaluation_config
        from .monitoring.policy_evaluation.runner import EXPERIMENTS, run_policy_evaluation

        output_root = config.resolve(Path(args.output_dir))
        if args.action == "plot":
            from .monitoring.policy_evaluation.reporting import plot_policy_evaluation

            paths = plot_policy_evaluation(output_root)
            if args.show:
                _open_paths(paths)
            print(json.dumps({"policy_evaluation_plots": [str(path) for path in paths]}, indent=2))
            return 0
        evaluation_path = config.resolve(Path(args.evaluation_config))
        evaluation = load_policy_evaluation_config(evaluation_path)
        if args.repetitions is not None:
            evaluation = replace(evaluation, repetitions=args.repetitions)
        selected = EXPERIMENTS if args.action == "all" else (args.action,)
        result = run_policy_evaluation(config, evaluation, output_root, selected)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0

    raise AssertionError(f"Unhandled command: {args.command}")



def main(argv: list[str] | None = None) -> int:
    import time
    started_ns = time.time_ns()
    args = _parser().parse_args(argv)
    physical_work = (
        args.command == "adaptive-monitoring" and args.action == "run"
        or
        args.command == "container-scale" and args.action in {"deploy", "stop", "run", "validate-reasoners"} and not args.dry_run
        or
        args.command == "campaign" and not args.validate_only
        or args.command == "physical" and args.action not in {"status", "authorize", "prepare"}
        or args.command in {"load", "experiment"} and getattr(args, "target", None) == "physical"
    )
    from contextlib import nullcontext
    from .monitoring.lease import (
        physical_lease,
        prevent_coordinator_suspension,
    )
    lease = physical_lease(load_config(args.config).root) if physical_work else nullcontext()
    from .monitoring.budget import execution_policy
    effective_unlimited = args.unlimited or (args.timeout_mode or load_config(args.config).limits.timeout_mode) == "unlimited"
    with (
        execution_policy(
            effective_unlimited,
            keep_going=args.keep_going or effective_unlimited,
        ),
        lease,
        prevent_coordinator_suspension(physical_work),
    ):
        if effective_unlimited:
            print("[execution-policy] unlimited: benchmark budgets are recorded but not enforced", flush=True)
        normalizes_outputs = args.command in {"physical", "load", "experiment"} and hasattr(args, "output_dir")
        previous_summaries = None
        if normalizes_outputs:
            from .monitoring.normalize import snapshot_summaries
            config = load_config(args.config)
            previous_summaries = snapshot_summaries(config.resolve(Path(args.output_dir)))
        status = _dispatch(args)
        if normalizes_outputs:
            from .monitoring.normalize import normalize_completed_outputs
            config = load_config(args.config)
            normalize_completed_outputs(config, config.resolve(Path(args.output_dir)), started_ns, previous_summaries=previous_summaries)
        return status


if __name__ == "__main__":
    raise SystemExit(main())
