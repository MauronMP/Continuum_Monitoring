"""HTTP worker used by configurable physical topologies."""

from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import asdict
import gc
import json
import os
from pathlib import Path
import platform
import resource
import signal
import struct
import sys
from threading import current_thread, main_thread
from threading import RLock
from time import perf_counter_ns, process_time_ns
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Iterator

from rdflib import Graph
from rdflib.compare import to_isomorphic

from . import __version__
from .config import load_config
from .ontology import load_graph
from .partitioning import deserialize_fragment, privacy_violations
from .protocol import SOFTWARE_BUILD_ID, WORKER_PROTOCOL_VERSION, WORKER_SERVICE
from .queries import execute_query, execute_query_detailed, load_catalog
from .reasoners import REASONING_CONTRACT, available_reasoners, materialize
from .specification import ONTOLOGY_REVISION, ONTOLOGY_VERSION
from .semantic_assets import semantic_assets_digest
from .synthetic import (
    add_synthetic_data,
    add_synthetic_rules,
    pad_to_target_triples,
)
from .topology import Topology, default_categories, infer_tier, load_topology


def _peak_rss_kib() -> int:
    """Return the process high-water RSS using one cross-platform unit."""

    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    # Linux reports KiB while Darwin reports bytes.
    return value // 1024 if sys.platform == "darwin" else value


def _children_usage() -> tuple[float, int]:
    """Cumulative CPU and lifetime high-water RSS of waited-for children.

    RUSAGE_CHILDREN excludes running/unreaped children. Its ru_maxrss is
    neither a per-preparation delta nor simultaneous process-tree memory.
    """
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    peak = int(usage.ru_maxrss)
    if sys.platform == "darwin":
        peak //= 1024
    return (usage.ru_utime + usage.ru_stime) * 1000, peak


def _current_rss_kib() -> int:
    """Return the current Linux resident set, with peak RSS as fallback."""

    try:
        for line in Path("/proc/self/status").read_text(
            encoding="utf-8"
        ).splitlines():
            if line.startswith("VmRSS:"):
                return int(line.split()[1])
    except (FileNotFoundError, PermissionError, ValueError, IndexError):
        pass
    return _peak_rss_kib()


def _process_io_bytes() -> tuple[int, int]:
    """Return process disk bytes from Linux procfs, or zeros when unavailable."""

    try:
        fields = {}
        for line in Path("/proc/self/io").read_text(
            encoding="utf-8"
        ).splitlines():
            key, value = line.split(":", 1)
            fields[key] = int(value.strip())
        return fields.get("read_bytes", 0), fields.get("write_bytes", 0)
    except (FileNotFoundError, PermissionError, ValueError):
        return 0, 0


def _total_memory_kib() -> int:
    try:
        for line in Path("/proc/meminfo").read_text(
            encoding="utf-8"
        ).splitlines():
            if line.startswith("MemTotal:"):
                return int(line.split()[1])
    except (FileNotFoundError, PermissionError, ValueError, IndexError):
        pass
    return 0


class WorkerPhaseTimeout(TimeoutError):
    """Raised inside a worker when its coordinator budget expires."""


@contextmanager
def _worker_timeout(seconds: float) -> Iterator[None]:
    """Interrupt CPU-bound Python reasoning while keeping the worker alive."""

    if (
        seconds <= 0
        or not hasattr(signal, "setitimer")
        or current_thread() is not main_thread()
    ):
        yield
        return
    previous_handler = signal.getsignal(signal.SIGALRM)

    def alarm_handler(signum, frame):  # noqa: ARG001
        raise WorkerPhaseTimeout(
            f"worker phase exceeded {seconds:.1f}s"
        )

    signal.signal(signal.SIGALRM, alarm_handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)


def _with_transport_metrics(
    payload: dict[str, Any],
    request_bytes: int,
) -> tuple[dict[str, Any], bytes]:
    """Attach exact HTTP body sizes and return the encoded response body."""

    payload["request_bytes"] = request_bytes
    payload["response_bytes"] = 0
    while True:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        encoded_size = len(encoded)
        if payload["response_bytes"] == encoded_size:
            return payload, encoded
        payload["response_bytes"] = encoded_size


class NodeRuntime:
    def __init__(
        self,
        root: Path,
        role: str,
        *,
        tier: str | None = None,
        topology_name: str | None = None,
        topology_file: str | Path = "configs/topologies/physical/topology.toml",
    ) -> None:
        self.root = root
        self.role = role
        self.node_id = role
        self.topology_name = topology_name or ""
        self.topology: Topology | None = None
        if topology_name:
            topology_path = Path(topology_file)
            if not topology_path.is_absolute():
                topology_path = root / topology_path
            self.topology = load_topology(topology_path, topology_name)
            configured_node = self.topology.node(role)
            if tier is not None and tier != configured_node.tier:
                raise ValueError(
                    f"Node {role!r} configured as tier {configured_node.tier!r}, "
                    f"not {tier!r}"
                )
            self.tier = configured_node.tier
            self.authority = configured_node.authority
            self.categories = configured_node.categories
        else:
            self.tier = tier or infer_tier(role)
            self.authority = self.tier in {"edge", "iot"}
            self.categories = default_categories(self.tier)
        self.config = load_config(root / "configs/benchmark.toml")
        self.semantic_digest = semantic_assets_digest(self.config)
        # The full logical graph is loaded lazily. Distributed workers otherwise
        # paid the memory cost of a replica they never queried.
        self.base_graph: Graph | None = None
        self.catalog = {
            spec.id: spec
            for spec in load_catalog(
                self.config.resolve(self.config.query_catalog),
                self.config.root,
            )
        }
        self.graph: Graph | None = None
        self.reasoner: str | None = None
        self.users: int | None = None
        self.seed = self.config.seed
        self.rule_count = 0
        self.target_triples = 0
        self.padding_mode = "semantic"
        self.mode = "replicated"
        self.lock = RLock()

    @staticmethod
    def _copy(source: Graph) -> Graph:
        graph = Graph()
        for prefix, namespace in source.namespaces():
            graph.bind(prefix, namespace)
        for triple in source:
            graph.add(triple)
        return graph

    def _logical_base(self) -> Graph:
        if self.base_graph is None:
            self.base_graph = load_graph(
                self.config.resolve(path)
                for path in self.config.ontology_files
            )
        return self.base_graph

    def prepare(
        self,
        reasoner: str,
        users: int,
        seed: int,
        mode: str = "replicated",
        rule_count: int = 0,
        target_triples: int = 0,
        padding_mode: str = "semantic",
        validate_graph_digest: bool = True,
        phase_timeout_seconds: float = 0,  # coordinator-only metadata
        fragment: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        with self.lock:
            if semantic_assets_digest(self.config) != self.semantic_digest:
                raise ValueError("Semantic assets changed after worker startup; synchronize and restart before preparing a graph")
            io_read_before, io_write_before = _process_io_bytes()
            cpu_started = process_time_ns()
            children_cpu_before, _ = _children_usage()
            started = perf_counter_ns()
            if mode == "replicated":
                source = self._copy(self._logical_base())
                fragments = None
                clone_ms = (perf_counter_ns() - started) / 1_000_000
                generated_at = perf_counter_ns()
                synthetic_triples = add_synthetic_data(source, users, seed)
                generation_ms = (
                    perf_counter_ns() - generated_at
                ) / 1_000_000
            elif mode == "distributed":
                if rule_count or target_triples:
                    raise ValueError(
                        "Distributed fragments must include coordinator-generated data"
                    )
                source, fragments = deserialize_fragment(
                    fragment, self.role, users=users, seed=seed,
                )
                clone_ms = 0.0
                generation_ms = (
                    perf_counter_ns() - started
                ) / 1_000_000
                synthetic_triples = fragments.synthetic_triples
            else:
                raise ValueError(
                    f"Unknown data mode {mode!r}; use replicated or distributed"
                )
            violations = (
                privacy_violations(
                    source,
                    self.role,
                    fragments.sensitive_resources,
                    authority=getattr(self, "authority", None),
                )
                if mode == "distributed"
                else []
            )
            if violations:
                raise ValueError(
                    f"Privacy gate rejected {len(violations)} facts on "
                    f"{self.role}: {violations[0]}"
                )
            rule_triples = 0
            padding_triples = 0
            if fragments is None:
                rule_triples = add_synthetic_rules(source, rule_count)
                padding_triples = pad_to_target_triples(
                    source, target_triples, mode=padding_mode,
                )
            input_graph_digest = ""
            input_graph_digest_ms = 0.0
            if validate_graph_digest:
                digest_started = perf_counter_ns()
                input_graph_digest = str(to_isomorphic(source).graph_digest())
                input_graph_digest_ms = (perf_counter_ns() - digest_started) / 1_000_000
            reasoning = materialize(source, reasoner)
            closure_graph_digest = ""
            closure_graph_digest_ms = 0.0
            if validate_graph_digest:
                closure_digest_started = perf_counter_ns()
                closure_graph_digest = str(to_isomorphic(reasoning.graph).graph_digest())
                closure_graph_digest_ms = (perf_counter_ns() - closure_digest_started) / 1_000_000
            self.graph = reasoning.graph
            self.reasoner = reasoner
            self.users = users
            self.seed = seed
            self.rule_count = rule_count
            self.target_triples = target_triples
            self.padding_mode = padding_mode
            self.mode = mode
            self.fragment = dict(fragment) if fragment is not None else None
            process_cpu_ms = (process_time_ns() - cpu_started) / 1_000_000
            children_cpu_after, child_peak_rss = _children_usage()
            io_read_after, io_write_after = _process_io_bytes()
            tier_name = getattr(self, "tier", None)
            if not tier_name:
                tier_name = infer_tier(self.role)
            return {
                "node_id": getattr(self, "node_id", self.role),
                "role": self.role,
                "tier_name": tier_name,
                "mode": mode,
                "reasoner": reasoner,
                **({"fragment_sha256": fragment["sha256"],
                    "fragment_contract": fragment["contract"],
                    "reasoning_scope": "local-fragment-closure"}
                   if fragments is not None else {}),
                "synthetic_users": users,
                "synthetic_triples": synthetic_triples,
                "synthetic_rule_count": rule_count,
                "synthetic_rule_triples": rule_triples,
                "padding_triples": padding_triples,
                "padding_mode": padding_mode,
                "clone_ms": clone_ms,
                "generation_ms": generation_ms,
                "reasoning_ms": reasoning.duration_ms,
                "input_triples": reasoning.input_triples,
                "logical_input_triples": (
                    reasoning.input_triples
                    if fragments is None
                    else (
                        fragments.substrate_triples
                        + fragments.reference_triples
                        + fragments.synthetic_triples
                        + fragments.padding_triples
                    )
                ),
                "output_triples": reasoning.output_triples,
                "inferred_triples": reasoning.inferred_triples,
                "input_graph_digest": input_graph_digest,
                "logical_input_graph_digest": (
                    input_graph_digest if fragments is None else fragments.logical_graph_digest
                ),
                "closure_graph_digest": closure_graph_digest,
                "input_graph_digest_ms": input_graph_digest_ms,
                "closure_graph_digest_ms": closure_graph_digest_ms,
                "logical_graph_digest_ms": (
                    0.0 if fragments is None else fragments.logical_graph_digest_ms
                ),
                "validation_digest_ms": input_graph_digest_ms + closure_graph_digest_ms,
                "children_cpu_ms": max(children_cpu_after - children_cpu_before, 0.0),
                "children_cpu_scope": "waited-for-children-phase-delta",
                "child_peak_rss_kib_lifetime": child_peak_rss,
                "child_peak_rss_scope": "waited-for-children-lifetime-high-water",
                "process_cpu_ms": process_cpu_ms,
                "process_cpu_scope": "worker-process-only-phase-delta",
                "current_rss_scope": "worker-process-only-current-or-lifetime-peak-fallback",
                "peak_rss_scope": "worker-process-only-lifetime-high-water",
                "current_rss_kib": _current_rss_kib(),
                "peak_rss_kib": _peak_rss_kib(),
                "disk_read_bytes": max(io_read_after - io_read_before, 0),
                "disk_write_bytes": max(
                    io_write_after - io_write_before, 0
                ),
                **(
                    {}
                    if fragments is None
                    else {
                        "profile": fragments.placement_profiles[self.role],
                        "local_substrate_triples": (
                            fragments.substrate_triples_by_role[self.role]
                        ),
                    }
                ),
            }

    def recover(self) -> dict[str, Any]:
        """Rebuild the last prepared application state after a logical loss."""

        with self.lock:
            if self.reasoner is None or self.users is None:
                raise RuntimeError("Node must be prepared before recovery")
            reasoner = self.reasoner
            users = self.users
            seed = self.seed
            mode = self.mode
            rule_count = self.rule_count
            target_triples = self.target_triples
            padding_mode = self.padding_mode
            self.graph = None
            gc.collect()
            started = perf_counter_ns()
            result = self.prepare(
                reasoner,
                users,
                seed,
                mode=mode,
                rule_count=rule_count,
                target_triples=target_triples,
                padding_mode=padding_mode,
                fragment=getattr(self, "fragment", None),
            )
            result["recovery_ms"] = (
                perf_counter_ns() - started
            ) / 1_000_000
            result["recovery_scope"] = "application_state_rebuild"
            return result

    def execute(
        self,
        query_ids: list[str],
        include_result_keys: bool = False,
    ) -> dict[str, Any]:
        with self.lock:
            if self.graph is None:
                raise RuntimeError("Node must be prepared before querying")
            unknown = sorted(set(query_ids) - set(self.catalog))
            if unknown:
                raise ValueError(f"Unknown query IDs: {unknown}")
            cpu_started = process_time_ns()
            io_read_before, io_write_before = _process_io_bytes()
            started = perf_counter_ns()
            measurements = []
            for query_id in query_ids:
                if include_result_keys:
                    execution = execute_query_detailed(
                        self.graph,
                        self.catalog[query_id],
                    )
                    item = asdict(execution.measurement)
                    item["result_keys"] = list(execution.result_keys)
                    item["result_group_keys"] = list(
                        execution.group_keys
                    )
                else:
                    item = asdict(
                        execute_query(self.graph, self.catalog[query_id])
                    )
                measurements.append(item)
            wall_ms = (perf_counter_ns() - started) / 1_000_000
            process_cpu_ms = (process_time_ns() - cpu_started) / 1_000_000
            io_read_after, io_write_after = _process_io_bytes()
            return {
                "role": self.role,
                "mode": self.mode,
                "reasoner": self.reasoner,
                "synthetic_users": self.users,
                "query_count": len(measurements),
                "query_wall_ms": wall_ms,
                "query_cpu_ms": sum(
                    float(item["duration_ms"]) for item in measurements
                ),
                "process_cpu_ms": process_cpu_ms,
                "process_cpu_scope": "worker-process-only-phase-delta",
                "current_rss_scope": "worker-process-only-current-or-lifetime-peak-fallback",
                "peak_rss_scope": "worker-process-only-lifetime-high-water",
                "current_rss_kib": _current_rss_kib(),
                "peak_rss_kib": _peak_rss_kib(),
                "disk_read_bytes": max(io_read_after - io_read_before, 0),
                "disk_write_bytes": max(
                    io_write_after - io_write_before, 0
                ),
                "measurements": measurements,
            }


class Handler(BaseHTTPRequestHandler):
    server: "NodeServer"

    def _json(
        self,
        status: int,
        payload: dict[str, Any],
        *,
        encoded: bytes | None = None,
    ) -> None:
        data = (
            encoded
            if encoded is not None
            else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        )
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            # Readiness probes may close after receiving enough headers. The
            # worker response was already computed and remains healthy.
            return

    def do_GET(self) -> None:  # noqa: N802
        if self.path != "/health":
            self._json(404, {"error": "not found"})
            return
        runtime = self.server.runtime
        try:
            assets_unchanged = semantic_assets_digest(runtime.config) == runtime.semantic_digest
            assets_error = None if assets_unchanged else "Semantic files changed after startup; restart required"
        except (OSError, ValueError, KeyError) as error:
            assets_unchanged = False
            assets_error = str(error)
        self._json(
            200,
            {
                "status": "ok" if assets_unchanged else "stale-semantic-assets",
                "semantic_assets_digest": runtime.semantic_digest,
                "semantic_assets_error": assets_error,
                "service": WORKER_SERVICE,
                "protocol_version": WORKER_PROTOCOL_VERSION,
                "benchmark_version": __version__,
                "build_id": SOFTWARE_BUILD_ID,
                "ontology_version": ONTOLOGY_VERSION,
                "ontology_revision": ONTOLOGY_REVISION,
                "query_count": len(runtime.catalog),
                "reasoning_contract": REASONING_CONTRACT,
                "registered_reasoners": list(available_reasoners()),
                "backend_availability": "verify-native-runtimes-before-benchmark",
                "node_id": runtime.node_id,
                "role": runtime.role,
                "tier": runtime.tier,
                "authority": runtime.authority,
                "categories": list(runtime.categories),
                "topology_name": runtime.topology_name,
                "topology_fingerprint": (
                    runtime.topology.fingerprint
                    if runtime.topology is not None
                    else ""
                ),
                "pid": os.getpid(),
                "python_version": platform.python_version(),
                "platform": platform.platform(),
                "machine": platform.machine(),
                "cpu_count": os.cpu_count() or 0,
                "pointer_bits": struct.calcsize("P") * 8,
                "total_memory_kib": _total_memory_kib(),
                "reasoner": runtime.reasoner,
                "synthetic_users": runtime.users,
                "synthetic_rule_count": runtime.rule_count,
                "target_triples": runtime.target_triples,
                "padding_mode": runtime.padding_mode,
                "mode": runtime.mode,
                "base_triples": (
                    len(runtime.base_graph)
                    if runtime.base_graph is not None
                    else 0
                ),
                "base_graph_loaded": runtime.base_graph is not None,
            },
        )

    def do_POST(self) -> None:  # noqa: N802
        request_started = perf_counter_ns()
        phase = self.path.strip("/") or "unknown"
        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length) or b"{}")
            print(
                f"[node-work] role={self.server.runtime.role} "
                f"phase={phase} reasoner={payload.get('reasoner', '-')} "
                f"users={payload.get('users', '-')} status=running",
                flush=True,
            )
            with _worker_timeout(
                float(payload.get("phase_timeout_seconds", 0))
            ):
                if self.path.startswith("/campaign/"):
                    from .monitoring.campaign_runtime import CampaignRuntime
                    runtime = self.server.runtime
                    if not hasattr(runtime, "campaign"):
                        runtime.campaign = CampaignRuntime()
                    if self.path == "/campaign/prepare":
                        result = runtime.campaign.prepare(payload)
                    elif self.path == "/campaign/query":
                        result = runtime.campaign.execute(payload)
                    else:
                        self._json(404, {"error": "not found"})
                        return
                elif self.path == "/prepare":
                    result = self.server.runtime.prepare(
                        fragment=payload.get("fragment"),
                        reasoner=str(payload["reasoner"]),
                        users=int(payload.get("users", 0)),
                        seed=int(payload.get("seed", 2026)),
                        mode=str(payload.get("mode", "replicated")),
                        rule_count=int(payload.get("rule_count", 0)),
                        target_triples=int(payload.get("target_triples", 0)),
                        padding_mode=str(
                            payload.get("padding_mode", "semantic")
                        ),
                        validate_graph_digest=bool(
                            payload.get("validate_graph_digest", True)
                        ),
                    )
                elif self.path == "/queries":
                    result = self.server.runtime.execute(
                        [str(value) for value in payload["query_ids"]],
                        include_result_keys=bool(
                            payload.get("include_result_keys", False)
                        ),
                    )
                elif self.path == "/recover":
                    result = self.server.runtime.recover()
                else:
                    self._json(404, {"error": "not found"})
                    return
            result, encoded = _with_transport_metrics(result, length)
            self._json(200, result, encoded=encoded)
            elapsed_ms = (perf_counter_ns() - request_started) / 1_000_000
            print(
                f"[node-work] role={self.server.runtime.role} "
                f"phase={phase} reasoner={result.get('reasoner', '-')} "
                f"users={result.get('synthetic_users', '-')} status=done "
                f"elapsed_ms={elapsed_ms:.2f}",
                flush=True,
            )
        except (BrokenPipeError, ConnectionResetError) as error:
            # The computation may have completed after a Wi-Fi client dropped.
            # Do not trigger a second write to the already closed socket.
            print(
                f"[node-work] role={self.server.runtime.role} "
                f"phase={phase} status=client-disconnected "
                f"error={type(error).__name__}",
                flush=True,
            )
        except WorkerPhaseTimeout as error:
            print(
                f"[node-work] role={self.server.runtime.role} "
                f"phase={phase} status=timeout error={error}",
                flush=True,
            )
            self._json(408, {"error": str(error), "timeout": True})
        except (KeyError, TypeError, ValueError, RuntimeError) as error:
            print(
                f"[node-work] role={self.server.runtime.role} "
                f"phase={phase} status=failed "
                f"error={type(error).__name__}: {error}",
                flush=True,
            )
            self._json(400, {"error": str(error)})
        except Exception as error:  # pragma: no cover - process boundary
            print(
                f"[node-work] role={self.server.runtime.role} "
                f"phase={phase} status=failed "
                f"error={type(error).__name__}: {error}",
                flush=True,
            )
            self._json(500, {"error": f"{type(error).__name__}: {error}"})

    def log_message(self, format: str, *args: object) -> None:
        print(
            f"[node role={self.server.runtime.role}] "
            f"{self.address_string()} {format % args}",
            flush=True,
        )


class NodeServer(HTTPServer):
    def __init__(self, address: tuple[str, int], runtime: NodeRuntime) -> None:
        super().__init__(address, Handler)
        self.runtime = runtime


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Elastic continuum worker node")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument(
        "--root",
        default=os.environ.get("CONTINUUM_ROOT", "/app"),
    )
    parser.add_argument(
        "--node-id",
        default=os.environ.get("CONTINUUM_NODE_ID"),
    )
    parser.add_argument(
        "--tier",
        default=os.environ.get("CONTINUUM_TIER"),
        choices=("cloud", "fog", "mist", "edge", "iot"),
    )
    parser.add_argument(
        "--topology-file",
        default=os.environ.get(
            "CONTINUUM_TOPOLOGY_FILE",
            "configs/topologies/physical/topology.toml",
        ),
    )
    parser.add_argument(
        "--topology-name",
        default=os.environ.get("CONTINUUM_TOPOLOGY_NAME"),
    )
    args = parser.parse_args(argv)
    node_id = args.node_id
    if not node_id:
        parser.error(
            "set --node-id (or CONTINUUM_NODE_ID); worker identities come "
            "from the selected composed topology manifest"
        )
    runtime = NodeRuntime(
        Path(args.root).resolve(),
        node_id,
        tier=args.tier,
        topology_name=args.topology_name,
        topology_file=args.topology_file,
    )
    server = NodeServer((args.host, args.port), runtime)
    previous_sigterm = signal.getsignal(signal.SIGTERM)

    def terminate_worker(signum, frame):  # noqa: ARG001
        # Raising through an active native request lets _run terminate the
        # reasoner's isolated process group before the worker exits.
        raise KeyboardInterrupt

    if current_thread() is main_thread():
        signal.signal(signal.SIGTERM, terminate_worker)
    print(
        f"[node] id={node_id} tier={runtime.tier} "
        f"listening={args.host}:{args.port} "
        "base_graph=lazy",
        flush=True,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        if current_thread() is main_thread():
            signal.signal(signal.SIGTERM, previous_sigterm)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
