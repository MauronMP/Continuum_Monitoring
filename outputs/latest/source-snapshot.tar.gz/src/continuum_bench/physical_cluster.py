"""Deployment and lifecycle helpers for an elastic physical topology."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import signal
import shutil
import subprocess
import sys
import time
from typing import Any
from urllib.error import URLError

from .monitoring.distributed import _request
from .protocol import worker_health_error
from .lifecycle_limits import ssh_probe_timeout, health_timeout
from .semantic_assets import semantic_assets_digest
from .config import load_config
from .environment import physical_checks, require_checks
from .topology import (
    Topology,
    load_topology,
    render_flat_topology,
)


_SSH_OPTIONS = (
    "-o",
    "BatchMode=yes",
    "-o",
    "ConnectTimeout=10",
    "-o",
    "ServerAliveInterval=5",
    "-o",
    "ServerAliveCountMax=2",
)
_RSYNC_SSH = "ssh " + " ".join(_SSH_OPTIONS)


@dataclass(frozen=True)
class PhysicalNode:
    role: str
    tier: str
    host: str
    endpoint: str
    local: bool
    port: int
    authority: bool
    categories: tuple[str, ...]

    @property
    def node_id(self) -> str:
        return self.role


@dataclass(frozen=True)
class PhysicalInventory:
    path: Path
    ssh_user: str
    remote_dir: str
    remote_python: str
    nodes: tuple[PhysicalNode, ...]
    topology_name: str = "physical"
    topology: Topology | None = None
    project_root: Path | None = None


def load_physical_inventory(
    path: Path,
    ssh_user: str | None = None,
    topology_name: str = "physical",
) -> PhysicalInventory:
    configured_topology = load_topology(path, topology_name)
    if configured_topology.kind != "physical":
        raise ValueError(
            f"Topology {topology_name!r} is not a physical topology"
        )
    nodes = tuple(
        PhysicalNode(
            role=item.node_id,
            tier=item.tier,
            host=item.host,
            endpoint=item.endpoint,
            local=item.local,
            port=item.port,
            authority=item.authority,
            categories=item.categories,
        )
        for item in configured_topology.active_nodes
    )
    user = ssh_user or configured_topology.ssh_user
    # Preserve placeholders until the optional command-line SSH user is
    # known. Otherwise --ssh-user would leave /home/{old-user} paths.
    remote_dir_template = configured_topology.remote_dir_template
    remote_python_template = configured_topology.remote_python_template
    project_root = configured_topology.project_root or path.parent
    if not nodes:
        raise ValueError("Physical inventory must define at least one node")
    roles = [node.role for node in nodes]
    endpoints = [node.endpoint for node in nodes]
    if len(roles) != len(set(roles)):
        raise ValueError(f"Duplicate physical node ids: {roles}")
    if len(endpoints) != len(set(endpoints)):
        raise ValueError(f"Duplicate physical endpoints: {endpoints}")
    if not any(node.local for node in nodes):
        raise ValueError("Inventory must define at least one local node")
    if not user:
        raise ValueError("Set cluster.ssh_user or pass --ssh-user")
    remote_dir = remote_dir_template.strip().format(
        ssh_user=user,
        root=str(project_root),
    )
    remote_python = remote_python_template.strip().format(
        ssh_user=user,
        root=str(project_root),
    )
    if not remote_dir.startswith("/") or not remote_python.startswith("/"):
        raise ValueError("remote_dir and remote_python must be absolute paths")
    _validate_remote_install_paths(remote_dir, remote_python, user)
    return PhysicalInventory(
        path=path,
        ssh_user=user,
        remote_dir=remote_dir,
        remote_python=remote_python,
        nodes=nodes,
        topology_name=topology_name,
        topology=configured_topology,
        project_root=project_root,
    )


def _validate_remote_install_paths(
    remote_dir: str,
    remote_python: str,
    user: str,
) -> None:
    """Reject deployment roots that could delete broad host directories."""

    directory = PurePosixPath(remote_dir)
    python_path = PurePosixPath(remote_python)
    if (
        len(directory.parts) < 3
        or ".." in directory.parts
        or str(directory)
        in {f"/home/{user}", f"/Users/{user}", "/root", "/tmp", "/var/tmp"}
        or not python_path.is_relative_to(directory)
        or ".." in python_path.parts
    ):
        raise ValueError(
            "Use a dedicated remote_dir below the user's home and a "
            "remote_python inside that directory; broad deployment targets "
            "are unsafe"
        )


# Shared with tools/install_owl_reasoners.py. These files contain host-local
# absolute Maven paths and must never be copied from the coordinator.
_JAVA_REASONERS = ("hermit", "openllet", "jfact")
_DL_ASSETS = ("tools/install_owl_reasoners.py", "tools/check_owl_consistency.py", "tools/owl")


def remote_reasoner_install_command(inventory: PhysicalInventory) -> str:
    """Render only; executing this is an explicit online deployment operation."""
    return (
        f"cd {shlex.quote(inventory.remote_dir)} || exit 20; "
        "if test -f .runtime/owl-reasoners.env; then "
        ". ./.runtime/owl-reasoners.env || exit 22; fi; "
        f"{shlex.quote(inventory.remote_python)} tools/install_owl_reasoners.py"
    )


def offline_preflight(root: Path, inventory: PhysicalInventory) -> dict[str, Any]:
    """Inspect local files and declared inventory only; no processes or network.

    Presence checks are not runtime certification. Remote placement remains
    pending until the actual target passes the installer installation checks.
    """
    root = root.resolve()
    assets = ("src", "configs", "ontology", "queries", "requirements-node.txt", *_DL_ASSETS)
    checks = [asdict(item) for item in physical_checks()]
    checks.append({"name": "python", "status": "ok" if sys.version_info >= (3, 11) else "error",
                   "detail": sys.version.split()[0]})
    checks.append({"name": "coordinator-platform",
                   "status": "ok" if sys.maxsize > 2**32 and (sys.platform.startswith("linux") or sys.platform == "darwin") else "error",
                   "detail": f"{sys.platform}; requires 64-bit Python"})
    for asset in assets:
        checks.append({"name": f"asset:{asset}", "status": "ok" if (root / asset).exists() else "error",
                       "detail": str(root / asset)})
    for command in ("java", "mvn"):
        checks.append({"name": command, "status": "ok" if shutil.which(command) else "error",
                       "detail": shutil.which(command) or "not installed; Java 17 and Maven required"})
    for reasoner in _JAVA_REASONERS:
        path = root / f".runtime/owl-validation-{reasoner}.classpath"
        value = os.environ.get(f"CONTINUUM_{reasoner.upper()}_CLASSPATH", "")
        if not value and path.is_file():
            value = path.read_text(encoding="utf-8").strip()
        entries = value.split(os.pathsep) if value else []
        import glob
        valid = bool(entries) and all(Path(entry).is_absolute() and any(Path(item).is_file() for item in glob.glob(entry)) for entry in entries)
        checks.append({"name": f"classpath:{reasoner}", "status": "ok" if valid else "error",
                       "detail": "local files present; execution unverified" if valid else "missing or invalid local classpath"})
    native = os.environ.get("CONTINUUM_KONCLUDE_EXECUTABLE") or shutil.which("Konclude")
    native_path = shutil.which(native) if native else None
    checks.append({"name": "konclude-native", "status": "ok" if native_path else "error",
                   "detail": native_path or "native Konclude required; no substitute permitted"})
    declared = {node.node_id: node for node in inventory.topology.nodes} if inventory.topology else {}
    nodes = []
    for node in inventory.nodes:
        metadata = declared.get(node.role)
        nodes.append({
            "node_id": node.role, "tier": node.tier, "host": node.host,
            "endpoint": node.endpoint, "local": node.local,
            "inventory_source": str(inventory.path),
            "device_type": metadata.device_type if metadata else None,
            "cpu_architecture": metadata.cpu_architecture if metadata else None,
            "cpu_cores": metadata.cpus if metadata else None,
            "memory": metadata.memory if metadata else None,
            "network_mbps": metadata.network_mbps if metadata else None,
            "location": {key: getattr(metadata, key) if metadata else None
                         for key in ("region", "latitude", "longitude", "altitude_m")},
            "evidence": "inventory declaration, not measured",
            "reachability": "not-probed", "runtime_verified": False,
            "placement_status": "pending-target-validation",
            "requirements": ["Python >=3.11 with venv and ensurepip", "Java 17 compatible with target OS/ABI",
                             "Maven", "native Konclude built for target OS/CPU/ABI", "target-local installer installation checks"],
        })
    return {
        "schema_version": 1, "mode": "offline", "remote_contacted": False,
        "deployment_ready": False,
        "local_files_ready": all(item["status"] == "ok" for item in checks),
        "checks": checks, "nodes": nodes,
        "remote_dir": inventory.remote_dir, "remote_python": inventory.remote_python,
        "future_install_command": remote_reasoner_install_command(inventory),
        "runtime_contract": {
            "installer": "tools/install_owl_reasoners.py",
            "classpath_files": [f".runtime/owl-validation-{name}.classpath" for name in _JAVA_REASONERS],
            "converter_classpath": ".runtime/owl-validation.classpath",
            "environment": ".runtime/owl-reasoners.env",
            "copy_coordinator_runtime": False, "fallback_allowed": False,
        },
    }


def write_offline_manifest(root: Path, inventory: PhysicalInventory, output: Path) -> dict[str, Any]:
    """Write a local readiness report; never deploy or start any worker."""
    manifest = offline_preflight(root, inventory)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def _run(command: list[str]) -> None:
    print(f"[physical-cluster] exec={shlex.join(command)}", flush=True)
    try:
        subprocess.run(command, check=True)
    except FileNotFoundError as error:
        raise RuntimeError(
            f"Required command not installed: {command[0]}. "
            "Run 'continuum-bench doctor --physical'."
        ) from error


def _ssh(target: str, *remote_command: str) -> list[str]:
    return ["ssh", *_SSH_OPTIONS, target, *remote_command]


def authorize_cluster(inventory: PhysicalInventory) -> None:
    """Install the local public key once, using one password prompt per host."""
    seen: set[str] = set()
    for node in inventory.nodes:
        if node.local:
            continue
        target = f"{inventory.ssh_user}@{node.host}"
        if target in seen:
            continue
        seen.add(target)
        print(
            f"[physical-cluster] role={node.role} host={node.host} "
            "phase=ssh-key-authorization",
            flush=True,
        )
        try:
            _run(["ssh-copy-id", target])
        except (FileNotFoundError, subprocess.CalledProcessError) as error:
            raise RuntimeError(
                f"Could not authorize SSH key for {target}. Ensure a local "
                "key exists with 'ssh-keygen -t ed25519', then retry "
                "'physical authorize'."
            ) from error


def _verify_key_auth(inventory: PhysicalInventory) -> None:
    """Fail before lifecycle work instead of blocking on password prompts."""
    failed: list[str] = []
    require_checks([item for item in physical_checks() if item.name == "ssh"])
    seen: set[str] = set()
    for node in inventory.nodes:
        if node.local:
            continue
        target = f"{inventory.ssh_user}@{node.host}"
        if target in seen:
            continue
        seen.add(target)
        try:
            result = subprocess.run(
                _ssh(target, "true"),
                check=False,
                capture_output=True,
                text=True,
                timeout=ssh_probe_timeout(),
            )
        except subprocess.TimeoutExpired as error:
            failed.append(f"{target}: SSH connectivity probe timed out after {error.timeout}s; authentication was not established. Check VPN connectivity or CONTINUUM_SSH_PROBE_TIMEOUT_SECONDS.")
            continue
        except OSError as error:
            failed.append(f"{target}: {error}")
            continue
        if result.returncode != 0:
            detail = (result.stderr or result.stdout).strip()
            failed.append(f"{target}: {detail or 'authentication failed'}")
    if failed:
        raise RuntimeError(
            "SSH preflight failed. Timeouts indicate incomplete connectivity checks, not missing credentials. "
            "For explicit permission-denied errors, run 'continuum-bench physical authorize --ssh-user USER'. "
            "Failures: "
            + "; ".join(failed)
        )


def _verify_remote_dependencies(inventory: PhysicalInventory) -> None:
    """Check every remote before rsync mutates any deployed release."""
    require_checks([item for item in physical_checks() if item.name in {"ssh", "rsync"}])
    python_check = (
        "import sys, venv, ensurepip; "
        "assert sys.version_info >= (3, 11), 'Python >=3.11 required'; "
        "print(sys.version.split()[0])"
    )
    command = " && ".join([
        "command -v rsync", "command -v pgrep", "command -v nohup",
        "python3 -c " + shlex.quote(python_check),
    ])
    failures = []
    seen: set[str] = set()
    for node in inventory.nodes:
        if node.local:
            continue
        target = f"{inventory.ssh_user}@{node.host}"
        if target in seen:
            continue
        seen.add(target)
        try:
            result = subprocess.run(_ssh(target, command), capture_output=True, text=True, timeout=ssh_probe_timeout(), check=False)
            if result.returncode:
                failures.append(f"{target}: {(result.stderr or result.stdout).strip()}")
        except subprocess.TimeoutExpired as error:
            failures.append(f"{target}: prerequisite probe timed out after {error.timeout}s; installed dependencies are unknown. Check VPN connectivity or CONTINUUM_SSH_PROBE_TIMEOUT_SECONDS.")
        except OSError as error:
            failures.append(f"{target}: {error}")
    if failures:
        raise RuntimeError(
            "Remote preflight failed before copying any files. A timeout does not establish missing dependencies. Only if the probe reports missing tools, install Python >=3.11, python3-venv, rsync and procps. "
            + "; ".join(failures)
        )


def deploy_cluster(
    root: Path,
    inventory: PhysicalInventory,
    *,
    with_dl_reasoners: bool = False,
) -> None:
    """Online deployment; optionally install and verify actual DL backends."""
    _verify_key_auth(inventory)
    _verify_remote_dependencies(inventory)
    sources = (
        root / "src",
        root / "configs",
        root / "ontology",
        root / "queries",
        root / "requirements-node.txt",
    )
    if with_dl_reasoners:
        sources += (root / "tools",)
    for source in sources:
        if not source.exists():
            raise FileNotFoundError(source)
    effective_topology = (
        render_flat_topology(
            inventory.topology,
            _runtime_dir(root) / "active-topology.toml",
        )
        if inventory.topology is not None
        else None
    )
    seen: set[str] = set()
    for node in inventory.nodes:
        if node.local:
            continue
        target = f"{inventory.ssh_user}@{node.host}"
        if target in seen:
            continue
        seen.add(target)
        _run(
            _ssh(
                target,
                "mkdir -p " + shlex.quote(inventory.remote_dir) + " "
                + shlex.quote(f"{inventory.remote_dir}/runtime"),
            )
        )
        for source in sources:
            rsync_options = ["rsync", "-az"]
            if source.is_dir():
                # Deployment directories are release-owned. Mirroring them
                # removes stale v2 query/category files without touching the
                # worker runtime, virtualenv, logs or any parent directory.
                rsync_options.append("--delete")
            _run(
                [
                    *rsync_options,
                    "-e",
                    _RSYNC_SSH,
                    str(source),
                    f"{target}:{shlex.quote(inventory.remote_dir + '/')}",
                ]
            )
        if inventory.topology is not None:
            # The selected catalogue or leaf may live at any path.
            # Copy it to a stable runtime path so deploy and start always use
            # exactly the topology validated by the coordinator.
            _run(
                [
                    "rsync",
                    "-az",
                    "-e",
                    _RSYNC_SSH,
                    str(effective_topology),
                    (
                        f"{target}:"
                        f"{shlex.quote(inventory.remote_dir + '/runtime/' + 'active-topology.toml')}"
                    ),
                ]
            )
        setup = (
            f"python3 -m venv {shlex.quote(inventory.remote_dir + '/.venv-node')}"
            f" && {shlex.quote(inventory.remote_dir + '/.venv-node/bin/pip')}"
            f" install --only-binary=:all: --retries 2 --timeout 60 -r "
            f"{shlex.quote(inventory.remote_dir + '/requirements-node.txt')}"
        )
        _run(_ssh(target, setup))
        if with_dl_reasoners:
            _run(_ssh(target, remote_reasoner_install_command(inventory)))
        print(
            f"[physical-cluster] role={node.role} host={node.host} "
            "status=deployed",
            flush=True,
        )


def _runtime_dir(root: Path) -> Path:
    path = root / "outputs" / "runtime" / "physical"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _local_start(
    root: Path,
    inventory: PhysicalInventory,
    node: PhysicalNode,
) -> None:
    runtime = _runtime_dir(root)
    pid_path = runtime / f"{node.role}.pid"
    if pid_path.is_file():
        pid = int(pid_path.read_text(encoding="utf-8").strip())
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            pid_path.unlink()
        else:
            raise RuntimeError(
                f"Local {node.role} appears to be running with PID {pid}"
            )
    log = (runtime / f"{node.role}.log").open("a", encoding="utf-8")
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(root / "src")
    command = [
        sys.executable,
        "-m",
        "continuum_bench.node",
        "--root",
        str(root),
        "--node-id",
        node.role,
        "--tier",
        node.tier,
    ]
    if inventory.topology is not None:
        command.extend(
            [
                "--topology-file",
                str(inventory.path),
                "--topology-name",
                inventory.topology_name,
            ]
        )
    command.extend(["--host", "0.0.0.0", "--port", str(node.port)])
    process = subprocess.Popen(
        command,
        cwd=root,
        env=environment,
        stdout=log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    pid_path.write_text(f"{process.pid}\n", encoding="utf-8")


def _remote_start(
    inventory: PhysicalInventory,
    node: PhysicalNode,
) -> None:
    target = f"{inventory.ssh_user}@{node.host}"
    runtime = f"{inventory.remote_dir}/runtime"
    pid_path = f"{runtime}/{node.role}.pid"
    log_path = f"{runtime}/{node.role}.log"
    worker_pattern = (
        "^"
        + re.escape(inventory.remote_python)
        + r" -m continuum_bench\.node .*--node-id "
        + re.escape(node.role)
        + r" .*--port "
        + str(node.port)
        + r"( |$)"
    )
    topology_arguments = (
        f"--topology-file "
        f"{shlex.quote(inventory.remote_dir + '/runtime/active-topology.toml')} "
        f"--topology-name {shlex.quote(inventory.topology_name)} "
        if inventory.topology is not None
        else ""
    )
    command = (
        f"mkdir -p {shlex.quote(runtime)} && "
        f"existing=$(pgrep -f {shlex.quote(worker_pattern)} "
        "2>/dev/null | head -n 1 || true); "
        'if test -n "$existing"; then '
        f"echo \"$existing\" > {shlex.quote(pid_path)}; exit 17; fi; "
        f"rm -f {shlex.quote(pid_path)}; "
        f"cd {shlex.quote(inventory.remote_dir)} || exit 20; "
        "if test -f .runtime/owl-reasoners.env; then "
        ". ./.runtime/owl-reasoners.env || exit 22; fi; "
        f"nohup env PYTHONPATH={shlex.quote(inventory.remote_dir + '/src')} "
        f"{shlex.quote(inventory.remote_python)} "
        "-m continuum_bench.node "
        f"--root {shlex.quote(inventory.remote_dir)} "
        f"--node-id {shlex.quote(node.role)} "
        f"--tier {shlex.quote(node.tier)} "
        f"{topology_arguments}"
        "--host 0.0.0.0 "
        f"--port {node.port} > {shlex.quote(log_path)} 2>&1 "
        "< /dev/null & worker_pid=$!; "
        f"echo \"$worker_pid\" > {shlex.quote(pid_path)}; "
        'sleep 1; if ! kill -0 "$worker_pid" 2>/dev/null; then '
        f"rm -f {shlex.quote(pid_path)}; "
        f"tail -n 20 {shlex.quote(log_path)} >&2; exit 21; fi"
    )
    _run(_ssh(target, command))


def start_cluster(
    root: Path,
    inventory: PhysicalInventory,
    wait_seconds: float = 30.0,
) -> None:
    _verify_key_auth(inventory)
    current = {
        item["role"]: item
        for item in status_cluster(inventory, print_output=False)
    }
    for node in inventory.nodes:
        if current[node.role]["healthy"]:
            print(
                f"[physical-cluster] role={node.role} host={node.host} "
                "status=already-running",
                flush=True,
            )
            continue
        if node.local:
            detail = current[node.role].get("detail", {})
            if (detail.get("service") == "continuum-benchmark-node"
                    and detail.get("node_id") == node.role
                    and isinstance(detail.get("pid"), int)):
                # Recover ownership after a failed startup overwrote the PID file.
                # _safe_local_stop independently verifies the process command.
                (_runtime_dir(root) / f"{node.role}.pid").write_text(f"{detail['pid']}\n")
            _safe_local_stop(root, node.role)
            _local_start(root, inventory, node)
        else:
            # A worker with a stale topology fingerprint is unhealthy by
            # contract but may still own the port. Stop only the exact managed
            # process before starting the current manifest revision.
            _safe_remote_stop(inventory, node)
            _remote_start(inventory, node)
        print(
            f"[physical-cluster] role={node.role} host={node.host} "
            "status=starting",
            flush=True,
        )
    deadline = time.monotonic() + wait_seconds
    while time.monotonic() < deadline:
        statuses = status_cluster(inventory, print_output=False)
        if all(item["healthy"] for item in statuses):
            print(
                f"[physical-cluster] nodes={len(inventory.nodes)} status=ready",
                flush=True,
            )
            return
        time.sleep(0.5)
    raise TimeoutError(
        "Physical nodes did not become healthy; run 'physical status' "
        "and inspect outputs/runtime/physical/cloud.log plus remote runtime logs"
    )


def _safe_local_stop(root: Path, role: str) -> None:
    pid_path = _runtime_dir(root) / f"{role}.pid"
    if not pid_path.is_file():
        return
    pid = int(pid_path.read_text(encoding="utf-8").strip())
    command = subprocess.run(
        ["ps", "-p", str(pid), "-o", "command="],
        check=False,
        capture_output=True,
        text=True,
    ).stdout
    if not command.strip():
        pid_path.unlink(missing_ok=True)
        return
    if (
        "continuum_bench.node" not in command
        or f"--node-id {role}" not in command
    ):
        raise RuntimeError(
            f"Refusing to stop PID {pid}: it is not the expected {role} worker"
        )
    tokens = shlex.split(command)
    if str(root) not in tokens:
        raise RuntimeError(f"Refusing to stop PID {pid}: worker belongs to another project")
    _stop_local_native_children(pid)
    os.kill(pid, signal.SIGTERM)
    deadline = time.monotonic() + 5.0
    while True:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            break
        if time.monotonic() >= deadline:
            raise TimeoutError(
                f"Local {role} worker PID {pid} did not stop within 5 seconds"
            )
        time.sleep(0.05)
    pid_path.unlink(missing_ok=True)


def _stop_local_native_children(worker_pid: int) -> None:
    """Stop only descendants of a worker whose identity was already verified.

    Matching a checkout path also matches independent validation/test processes;
    those must survive worker restarts. Unattributed orphans require manual review.
    """
    result = subprocess.run(
        ["ps", "-eo", "pid=,ppid="], check=False, capture_output=True, text=True,
    )
    parents = {}
    for line in result.stdout.splitlines():
        try:
            child, parent = map(int, line.split())
        except ValueError:
            continue
        parents[child] = parent
    descendants = {worker_pid}
    while True:
        expanded = descendants | {child for child, parent in parents.items() if parent in descendants}
        if expanded == descendants:
            break
        descendants = expanded
    pids = sorted(descendants - {worker_pid}, reverse=True)
    for pid in pids:
        try:
            group = os.getpgid(pid)
            if group == pid:
                os.killpg(group, signal.SIGTERM)
            else:
                os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            continue
    deadline = time.monotonic() + 5.0
    for pid in pids:
        while time.monotonic() < deadline:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
            time.sleep(0.05)
        else:
            try:
                group = os.getpgid(pid)
                if group == pid:
                    os.killpg(group, signal.SIGKILL)
                else:
                    os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass


def _safe_remote_stop(
    inventory: PhysicalInventory,
    node: PhysicalNode,
) -> None:
    target = f"{inventory.ssh_user}@{node.host}"
    pid_path = f"{inventory.remote_dir}/runtime/{node.role}.pid"
    worker_pattern = (
        "^"
        + re.escape(inventory.remote_python)
        + r" -m continuum_bench\.node .*--node-id "
        + re.escape(node.role)
        + r" .*--port "
        + str(node.port)
        + r"( |$)"
    )
    command = (
        f"pids=$(pgrep -f {shlex.quote(worker_pattern)} 2>/dev/null || true); "
        'for pid in $pids; do '
        # Native invocations are direct children with their own process group.
        # Capture ownership before stopping the parent; never match all Java
        # processes using the same checkout, including independent diagnostics.
        'children=$(pgrep -P "$pid" 2>/dev/null || true); '
        'for child in $children; do '
        'kill -TERM -- "-$child" 2>/dev/null || kill "$child" 2>/dev/null || true; '
        'done; '
        'kill "$pid"; '
        'attempt=0; while kill -0 "$pid" 2>/dev/null; do '
        'attempt=$((attempt + 1)); '
        'if test "$attempt" -ge 50; then exit 22; fi; sleep 0.1; '
        'done; '
        'for child in $children; do '
        'kill -KILL -- "-$child" 2>/dev/null || kill -KILL "$child" 2>/dev/null || true; '
        'done; done; '
        f"rm -f {shlex.quote(pid_path)}"
    )
    _run(_ssh(target, command))


def stop_cluster(root: Path, inventory: PhysicalInventory) -> None:
    _verify_key_auth(inventory)
    for node in inventory.nodes:
        if node.local:
            _safe_local_stop(root, node.role)
        else:
            _safe_remote_stop(inventory, node)
        print(
            f"[physical-cluster] role={node.role} host={node.host} "
            "status=stopped",
            flush=True,
        )


def status_cluster(
    inventory: PhysicalInventory,
    *,
    print_output: bool = True,
) -> list[dict[str, Any]]:
    expected_semantics = semantic_assets_digest(
        load_config(inventory.project_root / "configs/benchmark.toml")
        if inventory.project_root is not None else None
    )
    statuses: list[dict[str, Any]] = []
    for node in inventory.nodes:
        try:
            health = _request(node.endpoint, "/health", timeout=health_timeout())
            contract_error = worker_health_error(
                health,
                expected_semantic_digest=expected_semantics,
                expected_node_id=node.role,
                expected_tier=node.tier,
                expected_authority=node.authority,
                expected_categories=node.categories,
                expected_topology_fingerprint=(
                    inventory.topology.fingerprint
                    if inventory.topology is not None
                    else None
                ),
            )
            healthy = contract_error is None
            detail = {
                **health,
                **(
                    {}
                    if contract_error is None
                    else {"contract_error": contract_error}
                ),
            }
        except (OSError, URLError, TimeoutError) as error:
            healthy = False
            detail = {"error": str(error)}
        statuses.append(
            {
                "role": node.role,
                "node_id": node.role,
                "tier": node.tier,
                "host": node.host,
                "endpoint": node.endpoint,
                "healthy": healthy,
                "detail": detail,
            }
        )
    if print_output:
        print(json.dumps(statuses, indent=2, ensure_ascii=False))
    return statuses
