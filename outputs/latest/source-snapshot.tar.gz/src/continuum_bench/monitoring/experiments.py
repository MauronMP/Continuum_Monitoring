"""Three non-confounded experiments for continuum ontology evaluation.

The module deliberately separates replicated query scale-out, isolated
hardware reasoning, and authority-distributed ontology execution. A result
from one family must not be used as a measurement of another family.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import struct
from time import monotonic, perf_counter_ns
from typing import Any

import numpy as np

from .budget import (
    error_text,
    failure_status,
    is_boundary_failure,
    remaining_seconds,
)
from ..config import BenchmarkConfig
from ..csv_utils import write_dict_rows
from .distributed import Endpoint, _parallel, _request, discover
from .experiment_config import ExperimentConfig, ReasoningProfile
from .load_benchmark import _local_timeout
from ..queries import QuerySpec, execute_query_detailed, load_catalog
from ..semantic_assets import semantic_assets_digest
from ..specification import release_identity
from ..topology import Topology
from .budget import execution_metadata
from .distributed_ontology import (
    _prepare as distributed_prepare,
    _assignment as distributed_assignment,
    _baseline_counts,
    _merge_responses,
    _summary as distributed_summary,
    _validation_rows,
)


EXPERIMENTS = (
    "scale-out",
    "reasoning-hardware",
    "distributed-ontology",
    "distributed-reasoning-scalability",
)


def _write(path: Path, rows: list[dict[str, Any]]) -> None:
    write_dict_rows(path, rows, empty_message=f"No rows for {path}")


def _metadata(
    target: str,
    experiment: str,
    config: BenchmarkConfig,
    workload: ExperimentConfig,
    endpoints: list[Endpoint],
    topology: Topology | None = None,
) -> dict[str, Any]:
    endpoint_hardware = []
    for endpoint in endpoints:
        try:
            health = _request(
                endpoint.url,
                "/health",
                timeout=5.0,
                retries=0,
            )
        except Exception as error:
            endpoint_hardware.append(
                {
                    "url": endpoint.url,
                    "role": endpoint.role,
                    "metadata_error": f"{type(error).__name__}: {error}",
                }
            )
            continue
        endpoint_hardware.append(
            {
                key: health.get(key, "")
                for key in (
                    "node_id",
                    "role",
                    "tier",
                    "authority",
                    "python_version",
                    "platform",
                    "machine",
                    "cpu_count",
                    "pointer_bits",
                    "total_memory_kib",
                    "build_id",
                    "topology_fingerprint",
                )
            }
            | {"url": endpoint.url}
        )
    topology_fingerprints = sorted(
        {
            str(item["topology_fingerprint"])
            for item in endpoint_hardware
            if item.get("topology_fingerprint")
        }
    )
    return {
        **release_identity(), "semantic_assets_digest": semantic_assets_digest(config),
        "execution_policy": execution_metadata(),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "experiment": experiment,
        "architecture": target,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "reasoners": list(config.reasoners),
        "repetitions": workload.repetitions,
        "request_timeout_seconds": workload.request_timeout_seconds,
        "point_timeout_seconds": workload.point_timeout_seconds,
        "stop_after_timeout": workload.stop_after_timeout,
        "seed": workload.seed,
        "node_count": len(endpoints),
        "topology_fingerprint": (
            topology.fingerprint
            if topology
            else (
                topology_fingerprints[0]
                if len(topology_fingerprints) == 1
                else None
            )
        ),
        "worker_build_ids": sorted(
            {
                str(item["build_id"])
                for item in endpoint_hardware
                if item.get("build_id")
            }
        ),
        "endpoints": [
            {
                "url": endpoint.url,
                "node_id": endpoint.role,
                "tier": endpoint.tier,
                "authority": endpoint.authority,
            }
            for endpoint in endpoints
        ],
        "endpoint_hardware": endpoint_hardware,
    }


def _save_metadata(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _target_endpoints(
    config: BenchmarkConfig,
    target: str,
    endpoint_urls: list[str] | None,
    topology: Topology | None = None,
) -> list[Endpoint]:
    if target not in {"physical"}:
        raise ValueError("Experiment target must be physical")
    return discover(
        endpoint_urls or [],
        topology.active_nodes if topology else None,
        topology.fingerprint if topology else None,
        config,
    )


def _phase_payload(
    workload: ExperimentConfig,
    *,
    reasoner: str,
    users: int,
    mode: str,
    target_triples: int = 0,
    rule_count: int = 0,
    padding_mode: str = "neutral",
) -> dict[str, Any]:
    return {
        "reasoner": reasoner,
        "users": users,
        "seed": workload.seed,
        "mode": mode,
        "target_triples": target_triples,
        "rule_count": rule_count,
        "padding_mode": padding_mode,
        "phase_timeout_seconds": max(
            workload.request_timeout_seconds - 1.0,
            0.1,
        ),
    }


def _prepare_one(
    endpoint: Endpoint,
    payload: dict[str, Any],
    timeout: float,
) -> tuple[float, dict[str, Any]]:
    started = perf_counter_ns()
    result = _request(
        endpoint.url,
        "/prepare",
        payload,
        timeout=timeout,
        retries=0,
    )
    return (perf_counter_ns() - started) / 1_000_000, result


def _execute_one(
    endpoint: Endpoint,
    query_ids: list[str],
    timeout: float,
    *,
    include_result_keys: bool = False,
) -> tuple[float, dict[str, Any]]:
    started = perf_counter_ns()
    result = _request(
        endpoint.url,
        "/queries",
        {
            "query_ids": query_ids,
            "include_result_keys": include_result_keys,
            "phase_timeout_seconds": max(timeout - 1.0, 0.1),
        },
        timeout=timeout,
        retries=0,
    )
    return (perf_counter_ns() - started) / 1_000_000, result


def _replicated_prepare(
    endpoints: list[Endpoint],
    payload: dict[str, Any],
    timeout: float,
) -> tuple[float, dict[str, dict[str, Any]]]:
    return _parallel(
        endpoints,
        "/prepare",
        {endpoint.url: payload for endpoint in endpoints},
        phase="experiment-replicated-prepare",
        timeout=timeout,
        retries=0,
    )


def _execute_query_assignment(
    endpoints: list[Endpoint],
    assignment: dict[str, list[str]],
    timeout: float,
    *,
    include_result_keys: bool = False,
) -> tuple[float, dict[str, dict[str, Any]]]:
    payloads = {
        endpoint.url: {
            "query_ids": assignment[endpoint.url],
            "include_result_keys": include_result_keys,
            "phase_timeout_seconds": max(timeout - 1.0, 0.1),
        }
        for endpoint in endpoints
        if assignment[endpoint.url]
    }
    return _parallel(
        endpoints,
        "/queries",
        payloads,
        phase="experiment-balanced-queries",
        timeout=timeout,
        retries=0,
    )


def _calibrate_query_costs(
    endpoints: list[Endpoint],
    specs: list[QuerySpec],
    timeout: float,
    rounds: int,
) -> tuple[dict[str, dict[str, float]], bool]:
    """Learn per-node query costs outside measured rounds.

    Every replica executes every query, so calibration also proves that all
    active replicas expose the same result digest before load is distributed.
    """

    query_ids = [spec.id for spec in specs]
    samples: dict[tuple[str, str], list[float]] = defaultdict(list)
    digests: dict[str, set[str]] = defaultdict(set)
    for _ in range(max(rounds, 1)):
        assignment = {endpoint.url: query_ids for endpoint in endpoints}
        _, responses = _execute_query_assignment(
            endpoints,
            assignment,
            timeout,
        )
        for url, response in responses.items():
            for measurement in response["measurements"]:
                query_id = str(measurement["query_id"])
                samples[(url, query_id)].append(
                    float(measurement["duration_ms"])
                )
                digests[query_id].add(str(measurement["result_digest"]))
    costs = {
        endpoint.url: {
            spec.id: float(np.median(samples[(endpoint.url, spec.id)]))
            for spec in specs
        }
        for endpoint in endpoints
    }
    consistent = all(len(digests[spec.id]) == 1 for spec in specs)
    return costs, consistent


def _optimized_assignment(
    specs: list[QuerySpec],
    endpoints: list[Endpoint],
    costs: dict[str, dict[str, float]],
    *,
    rotation: int = 0,
) -> tuple[dict[str, list[str]], dict[str, float]]:
    """Greedy unrelated-machine scheduling using measured query costs."""

    rotated = specs[rotation % len(specs) :] + specs[: rotation % len(specs)]
    ordered = sorted(
        rotated,
        key=lambda spec: max(
            costs[endpoint.url][spec.id] for endpoint in endpoints
        ),
        reverse=True,
    )
    assignment = {endpoint.url: [] for endpoint in endpoints}
    predicted = {endpoint.url: 0.0 for endpoint in endpoints}
    for spec in ordered:
        selected = min(
            endpoints,
            key=lambda endpoint: (
                predicted[endpoint.url] + costs[endpoint.url][spec.id],
                predicted[endpoint.url],
                endpoint.role,
            ),
        )
        assignment[selected.url].append(spec.id)
        predicted[selected.url] += costs[selected.url][spec.id]
    return assignment, predicted


def _measurement_rows(
    responses: dict[str, dict[str, Any]],
    endpoints: list[Endpoint],
    common: dict[str, Any],
) -> list[dict[str, Any]]:
    roles = {endpoint.url: endpoint.role for endpoint in endpoints}
    return [
        {
            **common,
            "endpoint": url,
            "role": roles[url],
            **measurement,
        }
        for url, response in responses.items()
        for measurement in response["measurements"]
    ]


def run_scale_out(
    config: BenchmarkConfig,
    workload: ExperimentConfig,
    target: str,
    output_root: Path,
    endpoint_urls: list[str] | None = None,
    topology: Topology | None = None,
) -> Path:
    """Measure query scale-out after an explicitly excluded prepare phase."""

    all_endpoints = _target_endpoints(
        config, target, endpoint_urls, topology
    )
    specs = load_catalog(config.resolve(config.query_catalog), config.root)
    summary_rows: list[dict[str, Any]] = []
    query_rows: list[dict[str, Any]] = []
    node_counts = (
        workload.scale_out_node_counts
    )
    timeout = workload.request_timeout_seconds
    point_timeout = workload.point_timeout_seconds
    stopped_points: dict[tuple[int, str], str] = {}
    for node_count in node_counts:
        if node_count > len(all_endpoints):
            raise ValueError(
                f"{target} topology exposes {len(all_endpoints)} nodes, but "
                f"scale-out requests {node_count}; update node_counts or add "
                "nodes to the selected architecture layer files"
            )
        endpoints = all_endpoints[:node_count]
        for reasoner in config.reasoners:
            for repetition in range(1, workload.repetitions + 1):
                stop_key = (node_count, reasoner)
                label = (
                    f"[experiment-scale-out] architecture={target} "
                    f"nodes={node_count} reasoner={reasoner} "
                    f"repetition={repetition}/{workload.repetitions}"
                )
                if workload.stop_after_timeout and stop_key in stopped_points:
                    summary_rows.append(
                        {
                            "architecture": target,
                            "node_count": node_count,
                            "reasoner": reasoner,
                            "repetition": repetition,
                            "query_round": 0,
                            "status": "skipped_after_timeout",
                            "error": stopped_points[stop_key],
                        }
                    )
                    print(f"{label} status=skipped_after_timeout", flush=True)
                    continue
                print(f"{label} phase=prepare status=running", flush=True)
                payload = _phase_payload(
                    workload,
                    reasoner=reasoner,
                    users=workload.scale_out_users,
                    mode="replicated",
                    target_triples=workload.scale_out_target_triples,
                    rule_count=workload.scale_out_rule_count,
                    padding_mode=workload.scale_out_padding_mode,
                )
                point_started = monotonic()
                try:
                    prepare_wall_ms, prepared = _replicated_prepare(
                        endpoints,
                        payload,
                        min(timeout, remaining_seconds(point_started, point_timeout)),
                    )
                except Exception as error:
                    status = failure_status(error)
                    message = error_text(error)
                    summary_rows.append(
                        {
                            "architecture": target,
                            "node_count": node_count,
                            "reasoner": reasoner,
                            "repetition": repetition,
                            "query_round": 0,
                            "status": status,
                            "error": message,
                        }
                    )
                    print(
                        f"{label} phase=prepare status=failed error={error}",
                        flush=True,
                    )
                    if is_boundary_failure(error):
                        stopped_points[stop_key] = message
                    continue
                warmup_failed = ""
                warmup_boundary = False
                calibration_consistent = False
                query_costs: dict[str, dict[str, float]] = {}
                print(
                    f"{label} phase=calibration rounds="
                    f"{max(workload.warmup_query_rounds, 1)} "
                    "strategy=adaptive-lpt status=running",
                    flush=True,
                )
                try:
                    query_costs, calibration_consistent = (
                        _calibrate_query_costs(
                            endpoints,
                            specs,
                            min(
                                timeout,
                                remaining_seconds(point_started, point_timeout),
                            ),
                            workload.warmup_query_rounds,
                        )
                    )
                except Exception as error:
                    warmup_failed = error_text(error)
                    warmup_boundary = is_boundary_failure(error)
                if warmup_failed:
                    summary_rows.append(
                        {
                            "architecture": target,
                            "node_count": node_count,
                            "reasoner": reasoner,
                            "repetition": repetition,
                            "query_round": 0,
                            "status": "warmup_failed",
                            "error": warmup_failed,
                            "prepare_wall_ms_excluded": prepare_wall_ms,
                        }
                    )
                    print(
                        f"{label} phase=warmup status=failed "
                        f"error={warmup_failed}",
                        flush=True,
                    )
                    if warmup_boundary:
                        stopped_points[stop_key] = warmup_failed
                    continue
                known_digests: dict[str, str] = {}
                for query_round in range(1, workload.query_rounds + 1):
                    print(
                        f"{label} phase=query round={query_round}/"
                        f"{workload.query_rounds} status=running",
                        flush=True,
                    )
                    try:
                        assignment, predicted_load = _optimized_assignment(
                            specs,
                            endpoints,
                            query_costs,
                            rotation=query_round - 1,
                        )
                        query_wall_ms, responses = _execute_query_assignment(
                            endpoints,
                            assignment,
                            min(
                                timeout,
                                remaining_seconds(point_started, point_timeout),
                            ),
                        )
                    except Exception as error:
                        status = failure_status(error)
                        message = error_text(error)
                        summary_rows.append(
                            {
                                "architecture": target,
                                "node_count": node_count,
                                "reasoner": reasoner,
                                "repetition": repetition,
                                "query_round": query_round,
                                "status": status,
                                "error": message,
                                "prepare_wall_ms_excluded": prepare_wall_ms,
                            }
                        )
                        if is_boundary_failure(error):
                            stopped_points[stop_key] = message
                            break
                        continue
                    common = {
                        "architecture": target,
                        "node_count": node_count,
                        "reasoner": reasoner,
                        "repetition": repetition,
                        "query_round": query_round,
                    }
                    measurements = _measurement_rows(
                        responses, endpoints, common
                    )
                    query_rows.extend(measurements)
                    consistent = calibration_consistent
                    for item in measurements:
                        previous = known_digests.setdefault(
                            item["query_id"], item["result_digest"]
                        )
                        consistent &= previous == item["result_digest"]
                    durations = [
                        float(item["duration_ms"]) for item in measurements
                    ]
                    summary_rows.append(
                        {
                            **common,
                            "status": "completed",
                            "error": "",
                            "synthetic_users": workload.scale_out_users,
                            "target_triples_per_replica": (
                                workload.scale_out_target_triples
                            ),
                            "rule_count": workload.scale_out_rule_count,
                            "query_count": len(measurements),
                            "query_wall_ms": query_wall_ms,
                            "queries_per_second": (
                                len(measurements) / (query_wall_ms / 1000)
                                if query_wall_ms else 0.0
                            ),
                            "query_latency_p50_ms": float(
                                np.percentile(durations, 50)
                            ),
                            "query_latency_p95_ms": float(
                                np.percentile(durations, 95)
                            ),
                            "query_latency_p99_ms": float(
                                np.percentile(durations, 99)
                            ),
                            "result_digest_consistent": consistent,
                            "assignment_strategy": (
                                "calibrated-longest-processing-time"
                            ),
                            "assignment_counts": ",".join(
                                f"{endpoint.role}:"
                                f"{len(assignment[endpoint.url])}"
                                for endpoint in endpoints
                            ),
                            "predicted_max_node_query_ms": max(
                                predicted_load.values()
                            ),
                            "prepare_wall_ms_excluded": prepare_wall_ms,
                            "max_node_reasoning_ms_excluded": max(
                                float(item["reasoning_ms"])
                                for item in prepared.values()
                            ),
                            "logical_input_triples": max(
                                int(item["input_triples"])
                                for item in prepared.values()
                            ),
                            "aggregate_replica_triples": sum(
                                int(item["input_triples"])
                                for item in prepared.values()
                            ),
                            "storage_replication_factor": node_count,
                            "node_query_cpu_ms_sum": sum(
                                float(item["query_cpu_ms"])
                                for item in responses.values()
                            ),
                            "node_query_process_cpu_ms_sum": sum(
                                float(item.get("process_cpu_ms", 0.0))
                                for item in responses.values()
                            ),
                            "max_peak_rss_kib": max(
                                int(item.get("peak_rss_kib", 0))
                                for item in responses.values()
                            ),
                            "sum_current_rss_kib": sum(
                                int(item.get("current_rss_kib", 0))
                                for item in responses.values()
                            ),
                            "query_request_bytes_sum": sum(
                                int(item.get("request_bytes", 0))
                                for item in responses.values()
                            ),
                            "query_response_bytes_sum": sum(
                                int(item.get("response_bytes", 0))
                                for item in responses.values()
                            ),
                        }
                    )
                    print(
                        f"{label} phase=query round={query_round} status=done "
                        f"wall_ms={query_wall_ms:.2f}",
                        flush=True,
                    )
    output = output_root / "scale-out"
    _write(output / "summary.csv", summary_rows)
    if query_rows:
        _write(output / "query-runs.csv", query_rows)
    metadata = _metadata(
        target, "scale-out", config, workload, all_endpoints, topology
    )
    metadata.update(
        {
            "prepare_excluded_from_primary_timing": True,
            "layout": "full-replica-per-active-node",
            "query_distribution": (
                "per-node calibrated longest-processing-time scheduling"
            ),
            "node_counts": list(node_counts),
            "query_rounds": workload.query_rounds,
            "warmup_query_rounds": workload.warmup_query_rounds,
        }
    )
    _save_metadata(output / "metadata.json", metadata)
    return output


def _profile_value(profile: ReasoningProfile) -> int:
    return {
        "target_triples": profile.target_triples,
        "rule_count": profile.rule_count,
        "users": profile.users,
    }[profile.dimension]


def run_reasoning_hardware(
    config: BenchmarkConfig,
    workload: ExperimentConfig,
    target: str,
    output_root: Path,
    endpoint_urls: list[str] | None = None,
    topology: Topology | None = None,
) -> Path:
    """Measure each hardware endpoint independently, never as a cluster."""

    endpoints = _target_endpoints(config, target, endpoint_urls, topology)
    rows: list[dict[str, Any]] = []
    timeout = min(
        workload.request_timeout_seconds,
        workload.point_timeout_seconds,
    )
    stopped_dimensions: dict[tuple[str, str, str], str] = {}
    for endpoint in endpoints:
        for profile in workload.reasoning_profiles:
            for reasoner in config.reasoners:
                for repetition in range(1, workload.repetitions + 1):
                    label = (
                        "[experiment-reasoning-hardware] "
                        f"architecture={target} role={endpoint.role} "
                        f"profile={profile.name} reasoner={reasoner} "
                        f"repetition={repetition}/{workload.repetitions}"
                    )
                    print(f"{label} status=running", flush=True)
                    payload = _phase_payload(
                        workload,
                        reasoner=reasoner,
                        users=profile.users,
                        mode="replicated",
                        target_triples=profile.target_triples,
                        rule_count=profile.rule_count,
                        padding_mode=profile.padding_mode,
                    )
                    common = {
                        "architecture": target,
                        "endpoint": endpoint.url,
                        "role": endpoint.role,
                        "profile": profile.name,
                        "dimension": profile.dimension,
                        "dimension_value": _profile_value(profile),
                        "reasoner": reasoner,
                        "repetition": repetition,
                        "synthetic_users": profile.users,
                        "target_triples": profile.target_triples,
                        "rule_count": profile.rule_count,
                        "padding_mode": profile.padding_mode,
                    }
                    stop_key = (endpoint.url, reasoner, profile.dimension)
                    if workload.stop_after_timeout and stop_key in stopped_dimensions:
                        rows.append(
                            {
                                **common,
                                "status": "skipped_after_timeout",
                                "error": stopped_dimensions[stop_key],
                                "prepare_wall_ms": "",
                                "timeout_seconds": timeout,
                            }
                        )
                        print(
                            f"{label} status=skipped_after_timeout",
                            flush=True,
                        )
                        continue
                    try:
                        wall_ms, result = _prepare_one(
                            endpoint, payload, timeout
                        )
                    except Exception as error:
                        status = failure_status(error)
                        message = error_text(error)
                        rows.append(
                            {
                                **common,
                                "status": status,
                                "error": message,
                                "prepare_wall_ms": "",
                                "timeout_seconds": timeout,
                            }
                        )
                        print(
                            f"{label} status=failed error={error}",
                            flush=True,
                        )
                        if is_boundary_failure(error):
                            stopped_dimensions[stop_key] = message
                        continue
                    rows.append(
                        {
                            **common,
                            "status": "completed",
                            "error": "",
                            "prepare_wall_ms": wall_ms,
                            "generation_ms": result["generation_ms"],
                            "reasoning_ms": result["reasoning_ms"],
                            "input_triples": result["input_triples"],
                            "output_triples": result["output_triples"],
                            "inferred_triples": result["inferred_triples"],
                            "closure_expansion_factor": (
                                int(result["output_triples"])
                                / int(result["input_triples"])
                            ),
                            "process_cpu_ms": result["process_cpu_ms"],
                            "current_rss_kib": result["current_rss_kib"],
                            "peak_rss_kib": result["peak_rss_kib"],
                            "disk_read_bytes": result["disk_read_bytes"],
                            "disk_write_bytes": result["disk_write_bytes"],
                            "timeout_seconds": timeout,
                        }
                    )
                    print(
                        f"{label} status=done reasoning_ms="
                        f"{float(result['reasoning_ms']):.2f}",
                        flush=True,
                    )
    output = output_root / "reasoning-hardware"
    _write(output / "summary.csv", rows)
    metadata = _metadata(
        target, "reasoning-hardware", config, workload, endpoints, topology
    )
    metadata.update(
        {
            "execution": "one-endpoint-at-a-time",
            "cluster_aggregation": False,
            "timeout_is_right_censoring": True,
            "profiles": [
                {
                    "name": item.name,
                    "dimension": item.dimension,
                    "users": item.users,
                    "target_triples": item.target_triples,
                    "rule_count": item.rule_count,
                    "padding_mode": item.padding_mode,
                }
                for item in workload.reasoning_profiles
            ],
        }
    )
    _save_metadata(output / "metadata.json", metadata)
    return output


def run_distributed_ontology(
    config: BenchmarkConfig,
    workload: ExperimentConfig,
    target: str,
    output_root: Path,
    endpoint_urls: list[str] | None = None,
    topology: Topology | None = None,
) -> Path:
    """Compare one logical graph with an elastic authority partition."""

    endpoints = _target_endpoints(config, target, endpoint_urls, topology)
    specs = load_catalog(config.resolve(config.query_catalog), config.root)
    summary_rows: list[dict[str, Any]] = []
    query_rows: list[dict[str, Any]] = []
    validation_rows: list[dict[str, Any]] = []
    timeout = workload.request_timeout_seconds
    point_timeout = workload.point_timeout_seconds
    stopped_reasoners: dict[str, str] = {}
    for users in workload.distributed_users:
        for reasoner in config.reasoners:
            pending_validation: list[
                tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any]]
            ] = []
            for repetition in range(1, workload.repetitions + 1):
                label = (
                    "[experiment-distributed-ontology] "
                    f"architecture={target} users={users} "
                    f"reasoner={reasoner} "
                    f"repetition={repetition}/{workload.repetitions}"
                )
                print(f"{label} phase=prepare status=running", flush=True)
                common = {
                    "architecture": target,
                    "synthetic_users": users,
                    "reasoner": reasoner,
                    "repetition": repetition,
                    "node_count": len(endpoints),
                }
                if workload.stop_after_timeout and reasoner in stopped_reasoners:
                    summary_rows.append(
                        {
                            **common,
                            "status": "skipped_after_timeout",
                            "error": stopped_reasoners[reasoner],
                            "timeout_seconds": timeout,
                        }
                    )
                    print(
                        f"{label} status=skipped_after_timeout",
                        flush=True,
                    )
                    continue
                try:
                    point_started = monotonic()
                    prepare_wall_ms, prepared = distributed_prepare(
                        config,
                        endpoints,
                        reasoner,
                        users,
                        workload.seed,
                        timeout_seconds=min(
                            timeout,
                            remaining_seconds(point_started, point_timeout),
                        ),
                    )
                    assignment = distributed_assignment(specs, endpoints)
                    query_wall_ms, responses = _parallel(
                        endpoints,
                        "/queries",
                        {
                            url: {
                                "query_ids": [
                                    spec.id for spec in assigned
                                ],
                                "include_result_keys": True,
                                "phase_timeout_seconds": max(
                                    timeout - 1.0, 0.1
                                ),
                            }
                            for url, assigned in assignment.items()
                            if assigned
                        },
                        phase="experiment-federated-queries",
                        timeout=min(
                            timeout,
                            remaining_seconds(point_started, point_timeout),
                        ),
                        retries=0,
                    )
                    merged, raw = _merge_responses(
                        specs, endpoints, responses, common
                    )
                    query_rows.extend(
                        {**common, **item} for item in raw
                    )
                    summary = distributed_summary(
                        common,
                        len(specs),
                        prepare_wall_ms,
                        query_wall_ms,
                        prepared,
                        responses,
                    )
                    summary_row = {
                        **summary,
                        "status": "completed",
                        "error": "",
                        "result_validation_rate": "",
                        "reference_status": "pending",
                        "reference_error": "",
                    }
                    summary_rows.append(summary_row)
                    pending_validation.append(
                        (common, merged, summary_row)
                    )
                except Exception as error:
                    status = failure_status(error)
                    message = error_text(error)
                    summary_rows.append(
                        {
                            **common,
                            "status": status,
                            "error": message,
                            "timeout_seconds": timeout,
                        }
                    )
                    print(f"{label} status=failed error={error}", flush=True)
                    if is_boundary_failure(error):
                        stopped_reasoners[reasoner] = message
                    continue
                print(f"{label} status=done", flush=True)
            if pending_validation:
                print(
                    "[experiment-distributed-ontology] "
                    f"architecture={target} users={users} "
                    f"reasoner={reasoner} phase=reference-graph "
                    "status=running timing=excluded",
                    flush=True,
                )
                try:
                    with _local_timeout(timeout):
                        baseline = _baseline_counts(
                            config, specs, reasoner, users
                        )
                except Exception as error:
                    baseline_error = f"{type(error).__name__}: {error}"
                    for _, _, summary_row in pending_validation:
                        summary_row["reference_status"] = "failed"
                        summary_row["reference_error"] = baseline_error
                    print(
                        "[experiment-distributed-ontology] "
                        f"architecture={target} users={users} "
                        f"reasoner={reasoner} phase=reference-graph "
                        f"status=failed error={baseline_error}; "
                        "measurements remain explicitly unvalidated",
                        flush=True,
                    )
                    continue
                for common, merged, summary_row in pending_validation:
                    validation = _validation_rows(merged, baseline)
                    validation_rows.extend(
                        {**common, **item} for item in validation
                    )
                    valid_count = sum(
                        bool(item["valid"]) for item in validation
                    )
                    rate = valid_count / len(validation)
                    summary_row["result_validation_rate"] = rate
                    summary_row["reference_status"] = "completed"
                    if rate != 1.0:
                        summary_row["status"] = "invalid_results"
                        summary_row["error"] = (
                            f"{len(validation) - valid_count}/"
                            f"{len(validation)} query results differ from "
                            "the canonical reference graph"
                        )
                print(
                    "[experiment-distributed-ontology] "
                    f"architecture={target} users={users} "
                    f"reasoner={reasoner} phase=reference-graph "
                    "status=done",
                    flush=True,
                )
    output = output_root / "distributed-ontology"
    _write(output / "summary.csv", summary_rows)
    if query_rows:
        _write(output / "query-runs.csv", query_rows)
    if validation_rows:
        _write(output / "result-validation.csv", validation_rows)
    metadata = _metadata(
        target, "distributed-ontology", config, workload, endpoints, topology
    )
    metadata.update(
        {
            "layout": (
                "authority-and-privacy-distributed"
            ),
            "logical_dataset_is_equal_to_reference_graph": True,
            "distributed_reasoning": (
                "local materialisation per fragment plus federated "
                    "query merge"
            ),
            "validation": (
                "exact order-independent result bag against canonical reference graph"
            ),
            "ontology_placement_manifest": (
                str(config.root / "configs/ontology-placement.toml")
            ),
            "users": list(workload.distributed_users),
        }
    )
    _save_metadata(output / "metadata.json", metadata)
    return output


def run_experiment(
    name: str,
    config: BenchmarkConfig,
    workload: ExperimentConfig,
    target: str,
    output_root: Path,
    endpoint_urls: list[str] | None = None,
    topology: Topology | None = None,
) -> Path:
    runners = {
        "scale-out": run_scale_out,
        "reasoning-hardware": run_reasoning_hardware,
        "distributed-ontology": run_distributed_ontology,
    }
    try:
        runner = runners[name]
    except KeyError as error:
        raise ValueError(f"Unknown experiment {name!r}") from error
    return runner(
        config, workload, target, output_root, endpoint_urls, topology
    )
