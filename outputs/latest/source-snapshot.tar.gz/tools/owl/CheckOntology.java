import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.profiles.OWL2DLProfile;
import org.semanticweb.owlapi.profiles.OWLProfileReport;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

/** OWLAPI consistency check using a reasoner factory selected at runtime. */
class CheckOntology {
    private static String reasonerVersion(OWLReasoner reasoner) {
        try {
            org.semanticweb.owlapi.util.Version version = reasoner.getReasonerVersion();
            return version.getMajor() + "." + version.getMinor() + "." +
                version.getPatch() + "." + version.getBuild();
        } catch (RuntimeException incompatibleVersionMetadata) {
            // Version metadata is diagnostic and must not invalidate a
            // completed consistency check.
            return "unavailable";
        }
    }

    private static String quote(String value) {
        StringBuilder result = new StringBuilder("\"");
        for (int index = 0; index < value.length(); index++) {
            char c = value.charAt(index);
            if (c == '"' || c == '\\') {
                result.append('\\').append(c);
            } else if (c < 0x20) {
                result.append(String.format("\\u%04x", (int) c));
            } else {
                result.append(c);
            }
        }
        return result.append('"').toString();
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException(
                "usage: CheckOntology <ontology> <OWLReasonerFactory class>");
        }
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
        OWLOntology ontology = manager.loadOntologyFromOntologyDocument(new File(args[0]));
        OWLProfileReport profile = new OWL2DLProfile().checkOntology(ontology);
        Map<String, Integer> violations = new TreeMap<>();
        profile.getViolations().forEach(violation ->
            violations.merge(violation.getClass().getSimpleName(), 1, Integer::sum));
        Class<?> factoryClass = Class.forName(args[1]);
        Object factoryObject;
        try {
            factoryObject = factoryClass.getMethod("getInstance").invoke(null);
        } catch (NoSuchMethodException ignored) {
            factoryObject = factoryClass.getDeclaredConstructor().newInstance();
        }
        if (!(factoryObject instanceof OWLReasonerFactory)) {
            throw new IllegalArgumentException(args[1] + " is not an OWLReasonerFactory");
        }
        OWLReasonerFactory factory = (OWLReasonerFactory) factoryObject;
        OWLReasoner reasoner = factory.createReasoner(ontology);
        boolean consistent;
        List<String> unsatisfiable = new ArrayList<>();
        try {
            consistent = reasoner.isConsistent();
            if (consistent) {
                reasoner.getUnsatisfiableClasses().getEntitiesMinusBottom().forEach(
                    entity -> unsatisfiable.add(entity.getIRI().toString()));
            }
            unsatisfiable.sort(String::compareTo);
            String violationJson = violations.entrySet().stream()
                .map(entry -> quote(entry.getKey()) + ":" + entry.getValue())
                .collect(Collectors.joining(",", "{", "}"));
            String classesJson = unsatisfiable.stream().map(CheckOntology::quote)
                .collect(Collectors.joining(",", "[", "]"));
            String examplesJson = profile.getViolations().stream().map(Object::toString)
                .sorted().limit(5).map(CheckOntology::quote)
                .collect(Collectors.joining(",", "[", "]"));
            System.out.println("CONTINUUM_OWL_REPORT\t{" +
                "\"reasoner\":" + quote(reasoner.getReasonerName()) +
                ",\"reasoner_version\":" + quote(reasonerVersion(reasoner)) +
                ",\"axioms\":" + ontology.getAxiomCount() +
                ",\"consistent\":" + consistent +
                ",\"unsatisfiable_classes\":" + classesJson +
                ",\"owl2_dl_profile\":" + profile.isInProfile() +
                ",\"profile_violation_count\":" + profile.getViolations().size() +
                ",\"profile_violation_types\":" + violationJson +
                ",\"profile_violation_examples\":" + examplesJson + "}");
        } finally {
            reasoner.dispose();
        }
        if (!consistent || !unsatisfiable.isEmpty()) {
            System.exit(1);
        }
    }
}
